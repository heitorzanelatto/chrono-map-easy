-- Add barbeiro_id to track who blocked the time
ALTER TABLE public.horarios_bloqueados 
ADD COLUMN barbeiro_id uuid REFERENCES public.barbeiros(id) ON DELETE CASCADE;

-- Update RLS policies to allow barbeiros to manage their own blocked times
DROP POLICY IF EXISTS "Proprietarios podem inserir horarios bloqueados" ON public.horarios_bloqueados;
DROP POLICY IF EXISTS "Proprietarios podem atualizar horarios bloqueados" ON public.horarios_bloqueados;
DROP POLICY IF EXISTS "Proprietarios podem deletar horarios bloqueados" ON public.horarios_bloqueados;

-- Proprietarios can manage all blocked times
CREATE POLICY "Proprietarios podem gerenciar horarios bloqueados"
ON public.horarios_bloqueados
FOR ALL
USING (has_role(auth.uid(), 'proprietario'::app_role))
WITH CHECK (has_role(auth.uid(), 'proprietario'::app_role));

-- Barbeiros can insert their own blocked times
CREATE POLICY "Barbeiros podem inserir seus horarios bloqueados"
ON public.horarios_bloqueados
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.barbeiros 
    WHERE barbeiros.user_id = auth.uid() 
    AND barbeiros.id = barbeiro_id
  )
);

-- Barbeiros can view their own blocked times
CREATE POLICY "Barbeiros podem ver seus horarios bloqueados"
ON public.horarios_bloqueados
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.barbeiros 
    WHERE barbeiros.user_id = auth.uid() 
    AND barbeiros.id = barbeiro_id
  )
);

-- Barbeiros can update their own blocked times
CREATE POLICY "Barbeiros podem atualizar seus horarios bloqueados"
ON public.horarios_bloqueados
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.barbeiros 
    WHERE barbeiros.user_id = auth.uid() 
    AND barbeiros.id = barbeiro_id
  )
);

-- Barbeiros can delete their own blocked times
CREATE POLICY "Barbeiros podem deletar seus horarios bloqueados"
ON public.horarios_bloqueados
FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM public.barbeiros 
    WHERE barbeiros.user_id = auth.uid() 
    AND barbeiros.id = barbeiro_id
  )
);