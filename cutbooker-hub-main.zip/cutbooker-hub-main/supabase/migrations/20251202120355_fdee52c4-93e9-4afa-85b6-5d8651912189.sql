-- Allow anyone to view blocked times (for scheduling)
CREATE POLICY "Qualquer um pode ver horarios bloqueados"
ON public.horarios_bloqueados
FOR SELECT
USING (true);

-- Allow proprietarios to manage blocked times
CREATE POLICY "Proprietarios podem inserir horarios bloqueados"
ON public.horarios_bloqueados
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'proprietario'::app_role));

CREATE POLICY "Proprietarios podem atualizar horarios bloqueados"
ON public.horarios_bloqueados
FOR UPDATE
USING (has_role(auth.uid(), 'proprietario'::app_role));

CREATE POLICY "Proprietarios podem deletar horarios bloqueados"
ON public.horarios_bloqueados
FOR DELETE
USING (has_role(auth.uid(), 'proprietario'::app_role));