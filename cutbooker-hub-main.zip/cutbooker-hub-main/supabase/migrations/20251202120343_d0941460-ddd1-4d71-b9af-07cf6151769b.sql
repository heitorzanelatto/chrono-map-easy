-- Allow anyone to view active services
CREATE POLICY "Qualquer um pode ver servicos ativos"
ON public.servicos
FOR SELECT
USING (ativo = true);