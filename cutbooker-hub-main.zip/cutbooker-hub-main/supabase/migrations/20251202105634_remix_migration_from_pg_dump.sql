CREATE EXTENSION IF NOT EXISTS "pg_graphql";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "plpgsql";
CREATE EXTENSION IF NOT EXISTS "supabase_vault";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
--
-- PostgreSQL database dump
--


-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--



--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'cliente',
    'proprietario',
    'barbeiro'
);


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  insert into public.profiles (id, nome, telefone)
  values (new.id, new.raw_user_meta_data->>'nome', new.raw_user_meta_data->>'telefone');
  
  -- Set default role as cliente
  insert into public.user_roles (user_id, role)
  values (new.id, 'cliente');
  
  return new;
end;
$$;


--
-- Name: has_role(uuid, public.app_role); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_role(_user_id uuid, _role public.app_role) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select exists (
    select 1
    from public.user_roles
    where user_id = _user_id
      and role = _role
  )
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  new.updated_at = now();
  return new;
end;
$$;


SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    cliente_nome text NOT NULL,
    cliente_telefone text NOT NULL,
    cliente_email text,
    servico text NOT NULL,
    data date NOT NULL,
    horario time without time zone NOT NULL,
    status text DEFAULT 'pendente'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    barbeiro text DEFAULT 'Barbeiro 1'::text NOT NULL,
    barbeiro_id uuid,
    barbeiro_telefone text,
    CONSTRAINT appointments_status_check CHECK ((status = ANY (ARRAY['pendente'::text, 'concluido'::text, 'cancelado'::text])))
);


--
-- Name: barbeiros; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.barbeiros (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nome text NOT NULL,
    telefone text,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid,
    email text,
    nome_exibicao text
);


--
-- Name: horarios_bloqueados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.horarios_bloqueados (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    data date NOT NULL,
    horario_inicio time without time zone NOT NULL,
    horario_fim time without time zone NOT NULL,
    motivo text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: horarios_funcionamento; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.horarios_funcionamento (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dia_semana integer NOT NULL,
    horario_inicio time without time zone NOT NULL,
    horario_fim time without time zone NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT horarios_funcionamento_dia_semana_check CHECK (((dia_semana >= 0) AND (dia_semana <= 6)))
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    nome text NOT NULL,
    telefone text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: servicos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.servicos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nome text NOT NULL,
    preco numeric(10,2) NOT NULL,
    duracao_minutos integer NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: barbeiros barbeiros_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barbeiros
    ADD CONSTRAINT barbeiros_pkey PRIMARY KEY (id);


--
-- Name: barbeiros barbeiros_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barbeiros
    ADD CONSTRAINT barbeiros_user_id_unique UNIQUE (user_id);


--
-- Name: horarios_bloqueados horarios_bloqueados_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.horarios_bloqueados
    ADD CONSTRAINT horarios_bloqueados_pkey PRIMARY KEY (id);


--
-- Name: horarios_funcionamento horarios_funcionamento_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.horarios_funcionamento
    ADD CONSTRAINT horarios_funcionamento_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: servicos servicos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.servicos
    ADD CONSTRAINT servicos_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_key UNIQUE (user_id, role);


--
-- Name: idx_appointments_barbeiro_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_barbeiro_id ON public.appointments USING btree (barbeiro_id);


--
-- Name: idx_barbeiros_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_barbeiros_user_id ON public.barbeiros USING btree (user_id);


--
-- Name: unique_pending_appointments; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_pending_appointments ON public.appointments USING btree (barbeiro_id, data, horario) WHERE (status = 'pendente'::text);


--
-- Name: appointments update_appointments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_appointments_updated_at BEFORE UPDATE ON public.appointments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: barbeiros update_barbeiros_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_barbeiros_updated_at BEFORE UPDATE ON public.barbeiros FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: horarios_funcionamento update_horarios_funcionamento_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_horarios_funcionamento_updated_at BEFORE UPDATE ON public.horarios_funcionamento FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: servicos update_servicos_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_servicos_updated_at BEFORE UPDATE ON public.servicos FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: appointments appointments_barbeiro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_barbeiro_id_fkey FOREIGN KEY (barbeiro_id) REFERENCES public.barbeiros(user_id);


--
-- Name: appointments appointments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: barbeiros barbeiros_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barbeiros
    ADD CONSTRAINT barbeiros_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: appointments Anyone can create appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can create appointments" ON public.appointments FOR INSERT WITH CHECK (true);


--
-- Name: appointments Barbeiros podem atualizar seus agendamentos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Barbeiros podem atualizar seus agendamentos" ON public.appointments FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.barbeiros
  WHERE ((barbeiros.user_id = auth.uid()) AND (barbeiros.user_id = appointments.barbeiro_id)))));


--
-- Name: barbeiros Barbeiros podem ver seu próprio perfil; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Barbeiros podem ver seu próprio perfil" ON public.barbeiros FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: appointments Barbeiros podem ver seus próprios agendamentos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Barbeiros podem ver seus próprios agendamentos" ON public.appointments FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.barbeiros
  WHERE ((barbeiros.user_id = auth.uid()) AND (barbeiros.user_id = appointments.barbeiro_id)))));


--
-- Name: appointments Clientes can update their own appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Clientes can update their own appointments" ON public.appointments FOR UPDATE USING ((((auth.uid() IS NOT NULL) AND (auth.uid() = user_id)) OR public.has_role(auth.uid(), 'proprietario'::public.app_role)));


--
-- Name: appointments Clientes can view their own appointments by phone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Clientes can view their own appointments by phone" ON public.appointments FOR SELECT USING ((((auth.uid() IS NOT NULL) AND (auth.uid() = user_id)) OR public.has_role(auth.uid(), 'proprietario'::public.app_role)));


--
-- Name: user_roles Only proprietarios can view all roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Only proprietarios can view all roles" ON public.user_roles FOR SELECT USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: appointments Proprietarios can delete appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios can delete appointments" ON public.appointments FOR DELETE USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: appointments Proprietarios can update all appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios can update all appointments" ON public.appointments FOR UPDATE USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: appointments Proprietarios can view all appointments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios can view all appointments" ON public.appointments FOR SELECT USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: barbeiros Proprietarios podem atualizar barbeiros; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem atualizar barbeiros" ON public.barbeiros FOR UPDATE USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: horarios_funcionamento Proprietarios podem atualizar horarios; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem atualizar horarios" ON public.horarios_funcionamento FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: servicos Proprietarios podem atualizar servicos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem atualizar servicos" ON public.servicos FOR UPDATE USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: barbeiros Proprietarios podem deletar barbeiros; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem deletar barbeiros" ON public.barbeiros FOR DELETE USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: horarios_funcionamento Proprietarios podem deletar horarios; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem deletar horarios" ON public.horarios_funcionamento FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: servicos Proprietarios podem deletar servicos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem deletar servicos" ON public.servicos FOR DELETE USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: barbeiros Proprietarios podem inserir barbeiros; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem inserir barbeiros" ON public.barbeiros FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: horarios_funcionamento Proprietarios podem inserir horarios; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem inserir horarios" ON public.horarios_funcionamento FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: servicos Proprietarios podem inserir servicos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem inserir servicos" ON public.servicos FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: horarios_funcionamento Proprietarios podem ver horarios; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem ver horarios" ON public.horarios_funcionamento FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: barbeiros Proprietarios podem ver todos os barbeiros; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem ver todos os barbeiros" ON public.barbeiros FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: servicos Proprietarios podem ver todos os servicos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Proprietarios podem ver todos os servicos" ON public.servicos FOR SELECT USING (public.has_role(auth.uid(), 'proprietario'::public.app_role));


--
-- Name: horarios_funcionamento Qualquer um pode ver horarios ativos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Qualquer um pode ver horarios ativos" ON public.horarios_funcionamento FOR SELECT TO authenticated, anon USING ((ativo = true));


--
-- Name: barbeiros Qualquer um pode visualizar barbeiros ativos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Qualquer um pode visualizar barbeiros ativos" ON public.barbeiros FOR SELECT USING (((ativo = true) AND (user_id IS NOT NULL)));


--
-- Name: profiles Users can insert their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK ((auth.uid() = id));


--
-- Name: profiles Users can update their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = id));


--
-- Name: profiles Users can view their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own profile" ON public.profiles FOR SELECT USING ((auth.uid() = id));


--
-- Name: user_roles Users can view their own roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own roles" ON public.user_roles FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: appointments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

--
-- Name: barbeiros; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.barbeiros ENABLE ROW LEVEL SECURITY;

--
-- Name: horarios_bloqueados; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.horarios_bloqueados ENABLE ROW LEVEL SECURITY;

--
-- Name: horarios_funcionamento; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.horarios_funcionamento ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: servicos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.servicos ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--


