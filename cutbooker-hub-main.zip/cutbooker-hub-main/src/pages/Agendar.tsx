import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { PhoneInput } from "@/components/ui/phone-input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar as CalendarIcon, Clock, Scissors } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { supabaseQuery } from "@/lib/supabase-helpers";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const Agendar = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [barbeiros, setBarbeiros] = useState<Array<{ id: string; nome: string; telefone: string | null }>>([]);
  const [loadingBarbeiros, setLoadingBarbeiros] = useState(true);
  const [unavailableTimes, setUnavailableTimes] = useState<string[]>([]);
  const [loadingTimes, setLoadingTimes] = useState(false);
  const [showLoginDialog, setShowLoginDialog] = useState(false);
  const [loginDialogShown, setLoginDialogShown] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    service: "",
    date: "",
    time: "",
    barbeiro: "",
  });

  const [services, setServices] = useState<Array<{ id: string; nome: string; preco: number; duracao_minutos: number }>>([]);
  const [loadingServices, setLoadingServices] = useState(true);
  const [availableTimes, setAvailableTimes] = useState<string[]>([]);

  const fetchServicos = async () => {
    setLoadingServices(true);
    const { data, error } = await supabaseQuery
      .from("servicos")
      .select("id, nome, preco, duracao_minutos")
      .eq("ativo", true)
      .order("nome", { ascending: true });

    if (error) {
      toast({
        title: "Erro ao carregar serviços",
        description: error.message,
        variant: "destructive",
      });
    } else {
      setServices(data || []);
    }
    setLoadingServices(false);
  };

  const generateTimeSlots = (start: string, end: string, intervalMinutes: number = 30): string[] => {
    const slots: string[] = [];
    const [startHour, startMin] = start.split(':').map(Number);
    const [endHour, endMin] = end.split(':').map(Number);
    
    let currentMinutes = startHour * 60 + startMin;
    const endMinutes = endHour * 60 + endMin;
    
    while (currentMinutes < endMinutes) {
      const hours = Math.floor(currentMinutes / 60);
      const mins = currentMinutes % 60;
      slots.push(`${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`);
      currentMinutes += intervalMinutes;
    }
    
    return slots;
  };

  const calculateAvailableTimes = async () => {
    if (!formData.date || !formData.barbeiro || !formData.service) {
      setAvailableTimes([]);
      return;
    }

    setLoadingTimes(true);

    try {
      // Buscar duração do serviço
      const selectedService = services.find(s => s.nome === formData.service);
      const serviceDuration = selectedService?.duracao_minutos || 30;

      // Buscar horários de funcionamento para o dia da semana
      const selectedDate = new Date(formData.date + 'T00:00:00');
      const dayOfWeek = selectedDate.getDay();
      
      const { data: horariosFuncionamento, error: horarioError } = await supabaseQuery
        .from("horarios_funcionamento")
        .select("horario_inicio, horario_fim")
        .eq("dia_semana", dayOfWeek)
        .eq("ativo", true);

      if (horarioError) throw horarioError;

      if (!horariosFuncionamento || horariosFuncionamento.length === 0) {
        setAvailableTimes([]);
        setLoadingTimes(false);
        return;
      }

      // Gerar todos os slots possíveis dos horários de funcionamento
      let allSlots: string[] = [];
      horariosFuncionamento.forEach(horario => {
        const slots = generateTimeSlots(horario.horario_inicio, horario.horario_fim, 30);
        allSlots = [...allSlots, ...slots];
      });

      // Buscar user_id do barbeiro
      const { data: barbeiroData } = await supabaseQuery
        .from("barbeiros")
        .select("user_id")
        .eq("nome", formData.barbeiro)
        .maybeSingle();

      if (!barbeiroData?.user_id) {
        setAvailableTimes([]);
        setLoadingTimes(false);
        return;
      }

      // Buscar agendamentos existentes
      const { data: appointments } = await supabaseQuery
        .from("appointments")
        .select("horario, servico")
        .eq("barbeiro_id", barbeiroData.user_id)
        .eq("data", formData.date)
        .eq("status", "pendente");

      // Buscar bloqueios personalizados
      const { data: bloqueios } = await supabaseQuery
        .from("horarios_bloqueados")
        .select("horario_inicio, horario_fim")
        .eq("data", formData.date);

      // Criar mapa de horários ocupados considerando duração dos serviços
      const occupiedSlots = new Set<string>();

      // Processar agendamentos existentes
      if (appointments) {
        for (const apt of appointments) {
          const aptService = services.find(s => s.nome === apt.servico);
          const aptDuration = aptService?.duracao_minutos || 30;
          const [aptHour, aptMin] = apt.horario.slice(0, 5).split(':').map(Number);
          let aptMinutes = aptHour * 60 + aptMin;
          
          // Marcar todos os slots ocupados pela duração do serviço
          for (let i = 0; i < aptDuration; i += 30) {
            const h = Math.floor(aptMinutes / 60);
            const m = aptMinutes % 60;
            occupiedSlots.add(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`);
            aptMinutes += 30;
          }
        }
      }

      // Processar bloqueios personalizados
      if (bloqueios) {
        bloqueios.forEach(bloqueio => {
          const blockedSlots = generateTimeSlots(bloqueio.horario_inicio, bloqueio.horario_fim, 30);
          blockedSlots.forEach(slot => occupiedSlots.add(slot));
        });
      }

      // Filtrar slots disponíveis considerando a duração do serviço atual
      const available = allSlots.filter(slot => {
        const [hour, min] = slot.split(':').map(Number);
        let checkMinutes = hour * 60 + min;
        
        // Verificar se todos os slots necessários para a duração do serviço estão livres
        for (let i = 0; i < serviceDuration; i += 30) {
          const h = Math.floor(checkMinutes / 60);
          const m = checkMinutes % 60;
          const checkSlot = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
          
          if (occupiedSlots.has(checkSlot) || !allSlots.includes(checkSlot)) {
            return false;
          }
          checkMinutes += 30;
        }
        
        return true;
      });

      setAvailableTimes(available);
    } catch (error) {
      console.error("Erro ao calcular horários disponíveis:", error);
      setAvailableTimes([]);
    } finally {
      setLoadingTimes(false);
    }
  };

  useEffect(() => {
    fetchBarbeiros();
    fetchServicos();
    
    if (!user && !loginDialogShown) {
      setShowLoginDialog(true);
      setLoginDialogShown(true);
    }
    
    if (user) {
      fetchUserProfile();
    }
  }, [user]);

  const fetchUserProfile = async () => {
    if (!user) return;

    const { data, error } = await supabaseQuery
      .from("profiles")
      .select("nome, telefone")
      .eq("id", user.id)
      .maybeSingle();

    const nomeFromProfile = (!error && data?.nome) ? data.nome : undefined;
    const telefoneFromProfile = (!error && data?.telefone) ? data.telefone : undefined;

    const nomeFromAuth = (user.user_metadata as any)?.nome || (user.user_metadata as any)?.name || "";
    const telefoneFromAuth = (user.user_metadata as any)?.telefone || (user.user_metadata as any)?.phone || "";

    setFormData(prev => ({
      ...prev,
      name: nomeFromProfile ?? nomeFromAuth ?? "",
      phone: telefoneFromProfile ?? telefoneFromAuth ?? ""
    }));
  };

  const fetchBarbeiros = async () => {
    setLoadingBarbeiros(true);
    const { data, error } = await supabaseQuery
      .from("barbeiros")
      .select("id, nome, telefone")
      .eq("ativo", true)
      .not("user_id", "is", null)
      .order("nome", { ascending: true });

    if (error) {
      toast({
        title: "Erro ao carregar barbeiros",
        description: error.message,
        variant: "destructive",
      });
    } else {
      setBarbeiros(data || []);
    }
    setLoadingBarbeiros(false);
  };

  useEffect(() => {
    if (formData.barbeiro && formData.date && formData.service) {
      calculateAvailableTimes();
    } else {
      setAvailableTimes([]);
    }
  }, [formData.barbeiro, formData.date, formData.service, services]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const nomeFromAuth = (user?.user_metadata as any)?.nome || (user?.user_metadata as any)?.name || "";
    const telefoneFromAuth = (user?.user_metadata as any)?.telefone || (user?.user_metadata as any)?.phone || "";
    const effectiveName = formData.name || nomeFromAuth;
    const effectivePhone = formData.phone || telefoneFromAuth;
    
    if (!formData.service || !formData.date || !formData.time || !formData.barbeiro || (!user && (!formData.name || !formData.phone))) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    // Verificar se o horário selecionado está disponível
    if (!availableTimes.includes(formData.time)) {
      toast({
        title: "Horário indisponível",
        description: "Este horário não está mais disponível. Por favor, selecione outro horário.",
        variant: "destructive",
      });
      setFormData({ ...formData, time: "" });
      return;
    }

    setIsSubmitting(true);

    try {
      // Buscar o user_id e telefone do barbeiro selecionado
      const { data: barbeiroData } = await supabaseQuery
        .from("barbeiros")
        .select("user_id, telefone")
        .eq("nome", formData.barbeiro)
        .maybeSingle();

      if (!barbeiroData?.user_id) {
        toast({
          title: "Erro",
          description: "Barbeiro não encontrado. Tente novamente.",
          variant: "destructive",
        });
        setIsSubmitting(false);
        return;
      }

      // Verificar novamente se o horário está disponível antes de salvar (double-check)
      const { data: existingAppointments, error: checkError } = await supabaseQuery
        .from("appointments")
        .select("id, status")
        .eq("barbeiro_id", barbeiroData.user_id)
        .eq("data", formData.date)
        .eq("horario", formData.time)
        .eq("status", "pendente");

      if (checkError) {
        console.error("Erro ao verificar disponibilidade:", checkError);
      }

      if (existingAppointments && existingAppointments.length > 0) {
        toast({
          title: "Horário indisponível",
          description: "Este horário foi reservado recentemente. Por favor, selecione outro horário ou outro barbeiro.",
          variant: "destructive",
        });
        await calculateAvailableTimes(); // Atualizar lista de horários disponíveis
        setFormData({ ...formData, time: "" }); // Limpar horário selecionado
        setIsSubmitting(false);
        return;
      }

      const { error } = await supabaseQuery
        .from("appointments")
        .insert({
          cliente_nome: effectiveName,
          cliente_telefone: effectivePhone,
          servico: formData.service,
          data: formData.date,
          horario: formData.time,
          barbeiro: formData.barbeiro,
          barbeiro_id: barbeiroData.user_id,
          barbeiro_telefone: barbeiroData.telefone || null,
          user_id: user?.id || null,
          status: 'pendente'
        });

      // Verificar se o erro é de constraint de duplicata (código 23505)
      if (error) {
        if (error.code === '23505' || error.message?.includes('unique_pending_appointments')) {
          toast({
            title: "Horário indisponível",
            description: "Este horário acabou de ser reservado por outro cliente. Por favor, selecione outro horário ou outro barbeiro.",
            variant: "destructive",
          });
          await calculateAvailableTimes(); // Atualizar lista de horários disponíveis
          setFormData({ ...formData, time: "" }); // Limpar horário selecionado
          setIsSubmitting(false);
          return;
        }
        throw error;
      }

      const [year, month, day] = formData.date.split('-');
      const dateFormatted = `${day}/${month}/${year}`;
      
      toast({
        title: "Agendamento realizado!",
        description: `Seu horário foi agendado para ${dateFormatted} às ${formData.time} com ${formData.barbeiro}.`,
      });

      // Enviar dados para o webhook
      try {
        await fetch("https://fraser-patrick-minus-notify.trycloudflare.com/webhook-test/Novo-Agendamento",  {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          mode: "no-cors",
          body: JSON.stringify({
            cliente_nome: effectiveName,
            cliente_telefone: effectivePhone,
            barbeiro_nome: formData.barbeiro,
            barbeiro_telefone: barbeiroData.telefone || null,
            servico: formData.service,
            data: formData.date,
            hora: formData.time,
          }),
        });
        console.log("Dados do agendamento enviados para o webhook");
      } catch (webhookError) {
        console.error("Erro ao enviar para webhook:", webhookError);
        // Não mostrar erro ao usuário pois o agendamento foi criado com sucesso
      }

      // Reset form - mantém nome e telefone se usuário estiver logado
      if (user) {
        setFormData({
          ...formData,
          service: "",
          date: "",
          time: "",
          barbeiro: "",
        });
      } else {
        setFormData({
          name: "",
          phone: "",
          service: "",
          date: "",
          time: "",
          barbeiro: "",
        });
      }
    } catch (error: any) {
      toast({
        title: "Erro ao agendar",
        description: error.message || "Ocorreu um erro ao criar seu agendamento. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen">
      <Navbar />

      <AlertDialog open={showLoginDialog} onOpenChange={setShowLoginDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deseja fazer login antes de agendar?</AlertDialogTitle>
            <AlertDialogDescription>
              Fazendo login, seus dados serão preenchidos automaticamente e você poderá gerenciar seus agendamentos.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setShowLoginDialog(false)}>
              Não, continuar sem login
            </AlertDialogCancel>
            <AlertDialogAction onClick={() => navigate("/auth")}>
              Sim, fazer login
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <section className="pt-32 pb-24 bg-background">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h1 className="text-6xl md:text-7xl font-light mb-8 text-foreground">
              Agende Seu <span className="font-medium text-accent">Horário</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-light">
              Preencha o formulário abaixo e garanta seu atendimento
            </p>
          </div>

          <div className="max-w-2xl mx-auto">
            <Card className="p-10 border-0 shadow-[var(--shadow-lg)]">
              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome Completo *</Label>
                    <Input
                      id="name"
                      placeholder="Seu nome"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required={!user}
                    />
                    {user && formData.name && (
                      <p className="text-xs text-muted-foreground">Preenchido automaticamente do seu perfil</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefone *</Label>
                    <PhoneInput
                      id="phone"
                      placeholder="(11) 99999-9999"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      required={!user}
                    />
                  {user && formData.phone && (
                    <p className="text-xs text-muted-foreground">Preenchido automaticamente do seu perfil</p>
                  )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="service">Serviço *</Label>
                  <Select
                    value={formData.service}
                    onValueChange={(value) => setFormData({ ...formData, service: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um serviço" />
                    </SelectTrigger>
                    <SelectContent>
                      {loadingServices ? (
                        <SelectItem value="loading" disabled>Carregando...</SelectItem>
                      ) : services.length === 0 ? (
                        <SelectItem value="empty" disabled>Nenhum serviço disponível</SelectItem>
                      ) : (
                        services.map((service) => (
                          <SelectItem key={service.id} value={service.nome}>
                            {service.nome} - R$ {service.preco.toFixed(2)}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="barbeiro">Barbeiro *</Label>
                  <Select
                    value={formData.barbeiro}
                    onValueChange={(value) => setFormData({ ...formData, barbeiro: value })}
                    disabled={loadingBarbeiros}
                  >
                    <SelectTrigger>
                      <Scissors className="h-4 w-4 mr-2" />
                      <SelectValue placeholder={loadingBarbeiros ? "Carregando..." : "Selecione um barbeiro"} />
                    </SelectTrigger>
                    <SelectContent>
                      {barbeiros.length === 0 ? (
                        <div className="px-2 py-6 text-sm text-muted-foreground text-center">
                          Nenhum barbeiro disponível
                        </div>
                      ) : (
                        barbeiros.map((barber) => (
                          <SelectItem key={barber.id} value={barber.nome}>
                            {barber.nome}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="date">Data *</Label>
                    <div className="relative">
                      <CalendarIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="date"
                        type="date"
                        className="pl-10"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        min={new Date().toISOString().split('T')[0]}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="time">Horário *</Label>
                    <Select
                      value={formData.time}
                      onValueChange={(value) => setFormData({ ...formData, time: value })}
                      disabled={!formData.barbeiro || !formData.date || !formData.service || loadingTimes}
                    >
                      <SelectTrigger>
                        <Clock className="h-4 w-4 mr-2" />
                        <SelectValue 
                          placeholder={
                            !formData.barbeiro || !formData.date 
                              ? "Selecione barbeiro e data primeiro"
                              : !formData.service
                              ? "Selecione um serviço primeiro"
                              : loadingTimes 
                              ? "Calculando horários..." 
                              : availableTimes.length === 0
                              ? "Nenhum horário disponível"
                              : "Selecione o horário"
                          } 
                        />
                      </SelectTrigger>
                      <SelectContent>
                        {availableTimes.length === 0 ? (
                          <div className="px-2 py-6 text-sm text-muted-foreground text-center">
                            Nenhum horário disponível para este dia
                          </div>
                        ) : (
                          availableTimes.map((time) => (
                            <SelectItem key={time} value={time}>
                              {time}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="pt-4">
                  <Button type="submit" variant="accent" size="lg" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? "Agendando..." : "Confirmar Agendamento"}
                  </Button>
                </div>

                <p className="text-sm text-muted-foreground text-center">
                  * Campos obrigatórios
                </p>
              </form>
            </Card>

            <Card className="p-6 mt-6 bg-muted">
              <h3 className="font-semibold mb-2 text-foreground">Importante:</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Chegue com 5 minutos de antecedência</li>
                <li>• Em caso de atraso superior a 15 minutos, o horário poderá ser cancelado</li>
                <li>• Para cancelamentos, favor avisar com no mínimo 2 horas de antecedência</li>
                <li>• Aceitamos pagamento em dinheiro, cartão e PIX</li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Agendar;
