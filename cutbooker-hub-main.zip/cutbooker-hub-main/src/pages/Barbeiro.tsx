import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabaseQuery } from "@/lib/supabase-helpers";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Calendar, Clock, User, Phone, Scissors, CheckCircle, XCircle, CalendarOff } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import HorariosBloqueados from "@/components/HorariosBloqueados";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Appointment {
  id: string;
  cliente_nome: string;
  cliente_telefone: string;
  servico: string;
  data: string;
  horario: string;
  status: string;
  created_at: string;
}

const Barbeiro = () => {
  const { user, userRole, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [filteredAppointments, setFilteredAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("todos");
  const [dateFilter, setDateFilter] = useState("todos");
  const [barbeiroNome, setBarbeiroNome] = useState<string>("");
  const [barbeiroId, setBarbeiroId] = useState<string | null>(null);

  // Helper para converter string de data em Date local sem problemas de timezone
  const parseLocalDate = (dateString: string): Date => {
    const [year, month, day] = dateString.split('-').map(Number);
    return new Date(year, month - 1, day);
  };

  useEffect(() => {
    if (!loading) {
      if (!user) {
        navigate("/auth");
      } else if (userRole !== "barbeiro") {
        toast({
          title: "Acesso negado",
          description: "Você não tem permissão para acessar esta página.",
          variant: "destructive",
        });
        navigate("/");
      } else {
        fetchBarbeiroData();
      }
    }
  }, [user, userRole, loading, navigate]);

  const fetchBarbeiroData = async () => {
    try {
      // Buscar dados do barbeiro
      const { data: barbeiroData, error: barbeiroError } = await supabaseQuery
        .from("barbeiros")
        .select("id, nome_exibicao")
        .eq("user_id", user?.id)
        .maybeSingle();

      if (barbeiroError) throw barbeiroError;
      setBarbeiroNome(barbeiroData?.nome_exibicao || "");
      setBarbeiroId(barbeiroData?.id || null);

      // Buscar agendamentos
      await fetchAppointments();
    } catch (error: any) {
      toast({
        title: "Erro ao carregar dados",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchAppointments = async () => {
    try {
      const { data, error } = await supabaseQuery
        .from("appointments")
        .select("*")
        .eq("barbeiro_id", user?.id)
        .order("data", { ascending: true })
        .order("horario", { ascending: true });

      if (error) throw error;
      setAppointments(data || []);
      setFilteredAppointments(data || []);
    } catch (error: any) {
      toast({
        title: "Erro ao carregar agendamentos",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleStatusChange = async (appointmentId: string, newStatus: string) => {
    try {
      // Buscar dados completos do agendamento antes de atualizar
      const { data: appointmentData, error: fetchError } = await supabaseQuery
        .from("appointments")
        .select("*")
        .eq("id", appointmentId)
        .single();

      if (fetchError) throw fetchError;

      const { error } = await supabaseQuery
        .from("appointments")
        .update({ status: newStatus })
        .eq("id", appointmentId);

      if (error) throw error;

      // Enviar dados completos para o webhook
      try {
        await fetch("https://fraser-patrick-minus-notify.trycloudflare.com/webhook-test/mudar-status", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            cliente_nome: appointmentData.cliente_nome,
            cliente_telefone: appointmentData.cliente_telefone,
            servico: appointmentData.servico,
            data: appointmentData.data,
            horario: appointmentData.horario,
            barbeiro: appointmentData.barbeiro,
            status: newStatus,
          }),
        });
        console.log("Dados do agendamento enviados para o webhook de mudança de status");
      } catch (webhookError) {
        console.error("Erro ao enviar dados para o webhook:", webhookError);
      }

      toast({
        title: "Status atualizado",
        description: "O status do agendamento foi atualizado com sucesso.",
      });

      fetchAppointments();
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar status",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    let filtered = [...appointments];

    // Filtro de status
    if (statusFilter !== "todos") {
      filtered = filtered.filter((apt) => apt.status === statusFilter);
    }

    // Filtro de data
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (dateFilter === "hoje") {
      filtered = filtered.filter((apt) => {
        const aptDate = parseLocalDate(apt.data);
        aptDate.setHours(0, 0, 0, 0);
        return aptDate.getTime() === today.getTime();
      });
    } else if (dateFilter === "proximos") {
      filtered = filtered.filter((apt) => {
        const aptDate = parseLocalDate(apt.data);
        aptDate.setHours(0, 0, 0, 0);
        return aptDate.getTime() >= today.getTime();
      });
    } else if (dateFilter === "passados") {
      filtered = filtered.filter((apt) => {
        const aptDate = parseLocalDate(apt.data);
        aptDate.setHours(0, 0, 0, 0);
        return aptDate.getTime() < today.getTime();
      });
    }

    setFilteredAppointments(filtered);
  }, [statusFilter, dateFilter, appointments]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return <Badge className="bg-yellow-500">Pendente</Badge>;
      case "cancelado":
        return <Badge variant="destructive">Cancelado</Badge>;
      case "concluido":
        return <Badge className="bg-blue-500">Concluído</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getUpcomingCount = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return appointments.filter((apt) => {
      const aptDate = parseLocalDate(apt.data);
      aptDate.setHours(0, 0, 0, 0);
      return aptDate.getTime() >= today.getTime() && apt.status === "pendente";
    }).length;
  };

  const getTodayCount = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return appointments.filter((apt) => {
      const aptDate = parseLocalDate(apt.data);
      aptDate.setHours(0, 0, 0, 0);
      return aptDate.getTime() === today.getTime() && apt.status === "pendente";
    }).length;
  };

  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1 pt-20 pb-8 sm:pt-24 sm:pb-12">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-6 sm:mb-8">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold mb-1 sm:mb-2 tracking-tight">
              Painel do {barbeiroNome || "Barbeiro"}
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground">
              Gerencie seus agendamentos e horários
            </p>
          </div>

          {/* Estatísticas */}
          <div className="grid grid-cols-3 gap-3 sm:gap-4 mb-6 sm:mb-8">
            <Card className="text-center">
              <CardHeader className="p-4 sm:pb-3">
                <CardDescription className="text-xs sm:text-sm">Total</CardDescription>
                <CardTitle className="text-2xl sm:text-3xl font-bold text-foreground">
                  {appointments.length}
                </CardTitle>
              </CardHeader>
            </Card>
            <Card className="text-center">
              <CardHeader className="p-4 sm:pb-3">
                <CardDescription className="text-xs sm:text-sm">Hoje</CardDescription>
                <CardTitle className="text-2xl sm:text-3xl font-bold text-accent">
                  {getTodayCount()}
                </CardTitle>
              </CardHeader>
            </Card>
            <Card className="text-center">
              <CardHeader className="p-4 sm:pb-3">
                <CardDescription className="text-xs sm:text-sm">Pendentes</CardDescription>
                <CardTitle className="text-2xl sm:text-3xl font-bold text-amber-500">
                  {getUpcomingCount()}
                </CardTitle>
              </CardHeader>
            </Card>
          </div>

          {/* Tabs para Agendamentos e Bloqueios */}
          <Tabs defaultValue="agendamentos" className="space-y-4 sm:space-y-6">
            <TabsList className="grid w-full grid-cols-2 max-w-md h-auto">
              <TabsTrigger value="agendamentos" className="gap-2 text-sm">
                <Calendar className="h-4 w-4" />
                <span className="hidden sm:inline">Agendamentos</span>
                <span className="sm:hidden">Agenda</span>
              </TabsTrigger>
              <TabsTrigger value="bloqueios" className="gap-2 text-sm">
                <CalendarOff className="h-4 w-4" />
                Bloqueios
              </TabsTrigger>
            </TabsList>

            <TabsContent value="agendamentos" className="space-y-4 sm:space-y-6">
              {/* Filtros */}
              <Card>
                <CardHeader className="pb-4">
                  <CardTitle className="text-base sm:text-lg">Filtros</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-3 sm:gap-4">
                    <div>
                      <label className="text-xs sm:text-sm font-medium mb-2 block text-muted-foreground">
                        Status
                      </label>
                      <Select value={statusFilter} onValueChange={setStatusFilter}>
                        <SelectTrigger className="h-11">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todos">Todos</SelectItem>
                          <SelectItem value="pendente">Pendente</SelectItem>
                          <SelectItem value="concluido">Concluído</SelectItem>
                          <SelectItem value="cancelado">Cancelado</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-xs sm:text-sm font-medium mb-2 block text-muted-foreground">
                        Período
                      </label>
                      <Select value={dateFilter} onValueChange={setDateFilter}>
                        <SelectTrigger className="h-11">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todos">Todos</SelectItem>
                          <SelectItem value="hoje">Hoje</SelectItem>
                          <SelectItem value="proximos">Próximos</SelectItem>
                          <SelectItem value="passados">Passados</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Lista de Agendamentos */}
              <div className="space-y-3 sm:space-y-4">
                {filteredAppointments.length === 0 ? (
                  <Card>
                    <CardContent className="py-12 text-center">
                      <Calendar className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
                      <p className="text-muted-foreground text-sm">
                        Nenhum agendamento encontrado
                      </p>
                    </CardContent>
                  </Card>
                ) : (
                  filteredAppointments.map((appointment, index) => (
                    <Card 
                      key={appointment.id} 
                      className="animate-fade-in overflow-hidden"
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <CardContent className="p-4 sm:p-5">
                        <div className="flex flex-col gap-4">
                          {/* Header com nome e status */}
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0">
                                <User className="h-5 w-5 text-accent" />
                              </div>
                              <div className="min-w-0">
                                <p className="font-semibold text-base truncate">
                                  {appointment.cliente_nome}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {appointment.cliente_telefone}
                                </p>
                              </div>
                            </div>
                            {getStatusBadge(appointment.status)}
                          </div>

                          {/* Info */}
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
                            <div className="flex items-center gap-1.5 text-muted-foreground">
                              <Scissors className="h-4 w-4" />
                              <span>{appointment.servico}</span>
                            </div>
                            <div className="flex items-center gap-1.5 text-muted-foreground">
                              <Calendar className="h-4 w-4" />
                              <span>{format(parseLocalDate(appointment.data), "dd/MM", { locale: ptBR })}</span>
                            </div>
                            <div className="flex items-center gap-1.5 text-muted-foreground">
                              <Clock className="h-4 w-4" />
                              <span>{appointment.horario}</span>
                            </div>
                          </div>

                          {/* Actions */}
                          {appointment.status === "pendente" && (
                            <div className="flex gap-2 pt-2 border-t border-border/50">
                              <Button
                                size="sm"
                                variant="outline"
                                className="flex-1 h-10"
                                onClick={() => handleStatusChange(appointment.id, "concluido")}
                              >
                                <CheckCircle className="h-4 w-4 mr-1.5 text-emerald-500" />
                                Concluir
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="flex-1 h-10"
                                onClick={() => handleStatusChange(appointment.id, "cancelado")}
                              >
                                <XCircle className="h-4 w-4 mr-1.5 text-destructive" />
                                Cancelar
                              </Button>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="bloqueios">
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-4 rounded-2xl bg-muted/30">
                  <CalendarOff className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                  <p className="text-sm text-muted-foreground">
                    Bloqueie dias ou períodos em que você não estará disponível.
                  </p>
                </div>
                
                {barbeiroId ? (
                  <HorariosBloqueados barbeiroId={barbeiroId} />
                ) : (
                  <Card>
                    <CardContent className="py-12 text-center">
                      <CalendarOff className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
                      <p className="text-muted-foreground text-sm">
                        Não foi possível carregar os dados do barbeiro.
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Barbeiro;
