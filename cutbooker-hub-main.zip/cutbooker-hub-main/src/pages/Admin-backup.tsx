import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabaseQuery } from "@/lib/supabase-helpers";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Calendar, Clock, User, Phone, Scissors, CheckCircle, XCircle } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Appointment {
  id: string;
  cliente_nome: string;
  cliente_telefone: string;
  servico: string;
  data: string;
  horario: string;
  status: string;
  created_at: string;
}

const Barbeiro = () => {
  const { user, userRole, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [filteredAppointments, setFilteredAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("todos");
  const [dateFilter, setDateFilter] = useState("todos");
  const [barbeiroNome, setBarbeiroNome] = useState<string>("");

  // Helper para converter string de data em Date local sem problemas de timezone
  const parseLocalDate = (dateString: string): Date => {
    const [year, month, day] = dateString.split('-').map(Number);
    return new Date(year, month - 1, day);
  };

  useEffect(() => {
    if (!loading) {
      if (!user) {
        navigate("/auth");
      } else if (userRole !== "barbeiro") {
        toast({
          title: "Acesso negado",
          description: "Você não tem permissão para acessar esta página.",
          variant: "destructive",
        });
        navigate("/");
      } else {
        fetchAppointments();
      }
    }
  }, [user, userRole, loading, navigate]);

  const fetchAppointments = async () => {
    try {
      // Buscar nome de exibição do barbeiro
      const { data: barbeiroData, error: barbeiroError } = await supabaseQuery
        .from("barbeiros")
        .select("nome_exibicao")
        .eq("user_id", user?.id)
        .maybeSingle();

      if (barbeiroError) throw barbeiroError;
      setBarbeiroNome(barbeiroData?.nome_exibicao || "");

      // Buscar agendamentos
      const { data, error } = await supabaseQuery
        .from("appointments")
        .select("*")
        .eq("barbeiro_id", user?.id)
        .order("data", { ascending: true })
        .order("horario", { ascending: true });

      if (error) throw error;
      setAppointments(data || []);
      setFilteredAppointments(data || []);
    } catch (error: any) {
      toast({
        title: "Erro ao carregar agendamentos",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusChange = async (appointmentId: string, newStatus: string) => {
    try {
      // Buscar dados completos do agendamento antes de atualizar
      const { data: appointmentData, error: fetchError } = await supabaseQuery
        .from("appointments")
        .select("*")
        .eq("id", appointmentId)
        .single();

      if (fetchError) throw fetchError;

      const { error } = await supabaseQuery
        .from("appointments")
        .update({ status: newStatus })
        .eq("id", appointmentId);

      if (error) throw error;

      // Enviar dados completos para o webhook
      try {
        await fetch("https://fraser-patrick-minus-notify.trycloudflare.com/webhook-test/mudar-status", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            cliente_nome: appointmentData.cliente_nome,
            cliente_telefone: appointmentData.cliente_telefone,
            servico: appointmentData.servico,
            data: appointmentData.data,
            horario: appointmentData.horario,
            barbeiro: appointmentData.barbeiro,
            status: newStatus,
          }),
        });
        console.log("Dados do agendamento enviados para o webhook de mudança de status");
      } catch (webhookError) {
        console.error("Erro ao enviar dados para o webhook:", webhookError);
      }

      toast({
        title: "Status atualizado",
        description: "O status do agendamento foi atualizado com sucesso.",
      });

      fetchAppointments();
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar status",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    let filtered = [...appointments];

    // Filtro de status
    if (statusFilter !== "todos") {
      filtered = filtered.filter((apt) => apt.status === statusFilter);
    }

    // Filtro de data
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (dateFilter === "hoje") {
      filtered = filtered.filter((apt) => {
        const aptDate = parseLocalDate(apt.data);
        aptDate.setHours(0, 0, 0, 0);
        return aptDate.getTime() === today.getTime();
      });
    } else if (dateFilter === "proximos") {
      filtered = filtered.filter((apt) => {
        const aptDate = parseLocalDate(apt.data);
        aptDate.setHours(0, 0, 0, 0);
        return aptDate.getTime() >= today.getTime();
      });
    } else if (dateFilter === "passados") {
      filtered = filtered.filter((apt) => {
        const aptDate = parseLocalDate(apt.data);
        aptDate.setHours(0, 0, 0, 0);
        return aptDate.getTime() < today.getTime();
      });
    }

    setFilteredAppointments(filtered);
  }, [statusFilter, dateFilter, appointments]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return <Badge className="bg-yellow-500">Pendente</Badge>;
      case "cancelado":
        return <Badge variant="destructive">Cancelado</Badge>;
      case "concluido":
        return <Badge className="bg-blue-500">Concluído</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getUpcomingCount = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return appointments.filter((apt) => {
      const aptDate = parseLocalDate(apt.data);
      aptDate.setHours(0, 0, 0, 0);
      return aptDate.getTime() >= today.getTime() && apt.status === "pendente";
    }).length;
  };

  const getTodayCount = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return appointments.filter((apt) => {
      const aptDate = parseLocalDate(apt.data);
      aptDate.setHours(0, 0, 0, 0);
      return aptDate.getTime() === today.getTime() && apt.status === "pendente";
    }).length;
  };

  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 pt-24 pb-12">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">
              Painel do {barbeiroNome || "Barbeiro"}
            </h1>
            <p className="text-muted-foreground">Gerencie seus agendamentos e horários</p>
          </div>

          {/* Estatísticas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>Total de Agendamentos</CardDescription>
                <CardTitle className="text-3xl">{appointments.length}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>Agendamentos Hoje</CardDescription>
                <CardTitle className="text-3xl">{getTodayCount()}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>Próximos Pendentes</CardDescription>
                <CardTitle className="text-3xl">{getUpcomingCount()}</CardTitle>
              </CardHeader>
            </Card>
          </div>

          {/* Filtros */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Status</label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos</SelectItem>
                      <SelectItem value="pendente">Pendente</SelectItem>
                      <SelectItem value="concluido">Concluído</SelectItem>
                      <SelectItem value="cancelado">Cancelado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Período</label>
                  <Select value={dateFilter} onValueChange={setDateFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos</SelectItem>
                      <SelectItem value="hoje">Hoje</SelectItem>
                      <SelectItem value="proximos">Próximos</SelectItem>
                      <SelectItem value="passados">Passados</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Lista de Agendamentos */}
          <div className="space-y-4">
            {filteredAppointments.length === 0 ? (
              <Card>
                <CardContent className="pt-6 text-center text-muted-foreground">
                  Nenhum agendamento encontrado com os filtros selecionados.
                </CardContent>
              </Card>
            ) : (
              filteredAppointments.map((appointment) => (
                <Card key={appointment.id}>
                  <CardContent className="pt-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{appointment.cliente_nome}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Phone className="h-4 w-4" />
                          <span>{appointment.cliente_telefone}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Scissors className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{appointment.servico}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span>{format(parseLocalDate(appointment.data), "dd/MM/yyyy", { locale: ptBR })}</span>
                          <Clock className="h-4 w-4 text-muted-foreground ml-2" />
                          <span>{appointment.horario}</span>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2 md:items-end">
                        {getStatusBadge(appointment.status)}
                        
                        {appointment.status === "pendente" && (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleStatusChange(appointment.id, "concluido")}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Concluir
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleStatusChange(appointment.id, "cancelado")}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Cancelar
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Barbeiro;
