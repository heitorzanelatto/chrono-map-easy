import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabaseQuery } from "@/lib/supabase-helpers";
import { Loader2 } from "lucide-react";

interface Appointment {
  id: string;
  servico: string;
  data: string;
  horario: string;
  status: string;
  barbeiro: string;
}

const servicoPrices: { [key: string]: string } = {
  "Corte Simples": "R$ 30,00",
  "Corte + Barba": "R$ 50,00",
  "Barba": "R$ 25,00",
  "Corte Degradê": "R$ 40,00",
  "Corte + Sobrancelha": "R$ 40,00",
};

const MeusAgendamentos = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [filteredAppointments, setFilteredAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>("todos");
  const [dateFilter, setDateFilter] = useState<string>("todos");

  useEffect(() => {
    if (!user) {
      navigate("/auth");
      return;
    }
    fetchAppointments();
  }, [user, navigate]);

  const fetchAppointments = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data, error } = await supabaseQuery
        .from("appointments")
        .select("*")
        .eq("user_id", user.id)
        .order("data", { ascending: false })
        .order("horario", { ascending: false });

      if (error) throw error;

      setAppointments(data || []);
      setFilteredAppointments(data || []);
    } catch (error) {
      console.error("Erro ao buscar agendamentos:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let filtered = [...appointments];

    if (statusFilter !== "todos") {
      filtered = filtered.filter((apt) => apt.status === statusFilter);
    }

    if (dateFilter === "proximos") {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      filtered = filtered.filter((apt) => {
        const aptDate = new Date(apt.data + "T00:00:00");
        return aptDate >= today && apt.status === "pendente";
      });
    } else if (dateFilter === "passados") {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      filtered = filtered.filter((apt) => {
        const aptDate = new Date(apt.data + "T00:00:00");
        return aptDate < today || apt.status === "concluido" || apt.status === "cancelado";
      });
    }

    setFilteredAppointments(filtered);
  }, [statusFilter, dateFilter, appointments]);

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: "default" | "secondary" | "destructive" } = {
      pendente: "secondary",
      concluido: "default",
      cancelado: "destructive",
    };
    return <Badge variant={variants[status] || "default"}>{status}</Badge>;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString + "T00:00:00");
    return date.toLocaleDateString("pt-BR");
  };

  const getPendingCount = () => {
    return appointments.filter((apt) => apt.status === "pendente").length;
  };

  const getUpcomingCount = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return appointments.filter((apt) => {
      const aptDate = new Date(apt.data + "T00:00:00");
      return aptDate >= today && apt.status === "pendente";
    }).length;
  };

  if (loading) {
    return (
      <div className="min-h-screen">
        <Navbar />
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      
      <section className="pt-32 pb-20 bg-gradient-to-b from-muted to-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Meus Agendamentos</h1>
            <p className="text-muted-foreground text-lg">
              Acompanhe todos os seus agendamentos
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Total de Agendamentos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{appointments.length}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{getPendingCount()}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Próximos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{getUpcomingCount()}</div>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os status</SelectItem>
                <SelectItem value="pendente">Pendente</SelectItem>
                <SelectItem value="concluido">Concluído</SelectItem>
                <SelectItem value="cancelado">Cancelado</SelectItem>
              </SelectContent>
            </Select>

            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Filtrar por período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os períodos</SelectItem>
                <SelectItem value="proximos">Próximos</SelectItem>
                <SelectItem value="passados">Passados</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-6">
            {filteredAppointments.length === 0 ? (
              <Card>
                <CardContent className="pt-6 text-center text-muted-foreground">
                  Nenhum agendamento encontrado.
                </CardContent>
              </Card>
            ) : (
              filteredAppointments.map((appointment) => (
                <Card key={appointment.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-xl mb-2">
                          {appointment.servico}
                        </CardTitle>
                        <CardDescription className="text-lg font-semibold text-primary">
                          {servicoPrices[appointment.servico] || "Preço não disponível"}
                        </CardDescription>
                      </div>
                      {getStatusBadge(appointment.status)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-muted-foreground">Data</p>
                        <p className="font-medium">{formatDate(appointment.data)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Horário</p>
                        <p className="font-medium">{appointment.horario}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Barbeiro</p>
                        <p className="font-medium">{appointment.barbeiro}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default MeusAgendamentos;
