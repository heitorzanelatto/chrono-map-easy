import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabaseQuery } from "@/lib/supabase-helpers";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  Scissors, 
  CheckCircle, 
  XCircle,
  Users,
  Settings,
  DollarSign,
  Plus,
  Pencil,
  Save,
  X,
  ArrowLeft,
  Menu,
  CalendarOff
} from "lucide-react";
import HorariosBloqueados from "@/components/HorariosBloqueados";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PhoneInput } from "@/components/ui/phone-input";
import { EmailInput } from "@/components/ui/email-input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { z } from "zod";

interface Appointment {
  id: string;
  cliente_nome: string;
  cliente_telefone: string;
  servico: string;
  data: string;
  horario: string;
  barbeiro: string;
  status: string;
  created_at: string;
}

interface Barbeiro {
  id: string;
  nome: string;
  nome_exibicao: string | null;
  telefone: string | null;
  email: string | null;
  ativo: boolean;
  user_id: string | null;
}

interface Servico {
  id: string;
  nome: string;
  preco: number;
  duracao_minutos: number;
  ativo: boolean;
}

interface HorarioFuncionamento {
  id: string;
  dia_semana: number;
  horario_inicio: string;
  horario_fim: string;
  ativo: boolean;
}

interface HorarioBloqueado {
  id: string;
  data: string;
  horario_inicio: string;
  horario_fim: string;
  motivo: string | null;
}

type ViewType = "menu" | "agendamentos" | "barbeiros" | "servicos" | "horarios" | "bloqueios";

const barbeiroSchema = z.object({
  nome: z.string().min(3, "Nome deve ter no mínimo 3 caracteres"),
  nome_exibicao: z.string().min(3, "Nome de exibição deve ter no mínimo 3 caracteres"),
  telefone: z.string().min(1, "Telefone é obrigatório"),
  email: z.string().email("Email inválido"),
  senha: z.string().min(6, "Senha deve ter no mínimo 6 caracteres"),
});

const barbeiroEditSchema = z.object({
  nome: z.string().min(3, "Nome deve ter no mínimo 3 caracteres"),
  nome_exibicao: z.string().min(3, "Nome de exibição deve ter no mínimo 3 caracteres"),
  telefone: z.string().optional(),
  email: z.string().email("Email inválido").optional().or(z.literal("")),
});

const servicoSchema = z.object({
  nome: z.string().min(3, "Nome deve ter no mínimo 3 caracteres"),
  preco: z.number().min(0, "Preço deve ser maior que zero"),
  duracao_minutos: z.number().min(15, "Duração mínima de 15 minutos"),
});

const horarioSchema = z.object({
  dia_semana: z.number().min(0).max(6),
  horario_inicio: z.string().regex(/^\d{2}:\d{2}$/, "Formato inválido (HH:MM)"),
  horario_fim: z.string().regex(/^\d{2}:\d{2}$/, "Formato inválido (HH:MM)"),
});

const Admin = () => {
  const { user, userRole, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [currentView, setCurrentView] = useState<ViewType>("menu");
  
  // Agendamentos
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [filteredAppointments, setFilteredAppointments] = useState<Appointment[]>([]);
  const [statusFilter, setStatusFilter] = useState("todos");
  const [dateFilter, setDateFilter] = useState("todos");
  
  // Barbeiros
  const [barbeiros, setBarbeiros] = useState<Barbeiro[]>([]);
  const [editingBarbeiro, setEditingBarbeiro] = useState<string | null>(null);
  const [deletingBarbeiroId, setDeletingBarbeiroId] = useState<string | null>(null);
  const [barbeiroForm, setBarbeiroForm] = useState({
    nome: "",
    nome_exibicao: "",
    telefone: "",
    email: "",
    senha: "",
  });
  const [isCreatingBarbeiro, setIsCreatingBarbeiro] = useState(false);
  
  // Serviços
  const [servicos, setServicos] = useState<Servico[]>([]);
  const [editingServico, setEditingServico] = useState<string | null>(null);
  const [deletingServicoId, setDeletingServicoId] = useState<string | null>(null);
  const [servicoForm, setServicoForm] = useState({
    nome: "",
    preco: "",
    duracao_minutos: "",
  });
  
  // Horários
  const [horarios, setHorarios] = useState<HorarioFuncionamento[]>([]);
  const [editingHorario, setEditingHorario] = useState<string | null>(null);
  const [deletingHorarioId, setDeletingHorarioId] = useState<string | null>(null);
  const [horarioForm, setHorarioForm] = useState({
    dia_semana: "",
    horario_inicio: "",
    horario_fim: "",
  });
  
  // Bloqueios de horários
  const [bloqueios, setBloqueios] = useState<HorarioBloqueado[]>([]);
  const [editingBloqueio, setEditingBloqueio] = useState<string | null>(null);
  const [deletingBloqueioId, setDeletingBloqueioId] = useState<string | null>(null);
  const [bloqueioForm, setBloqueioForm] = useState({
    data: "",
    horario_inicio: "",
    horario_fim: "",
    motivo: "",
  });
  
  const [isLoading, setIsLoading] = useState(true);

  const parseLocalDate = (dateString: string): Date => {
    const [year, month, day] = dateString.split('-').map(Number);
    return new Date(year, month - 1, day);
  };

  useEffect(() => {
    if (!loading) {
      if (!user) {
        navigate("/auth");
      } else if (userRole !== "proprietario") {
        toast({
          title: "Acesso negado",
          description: "Você não tem permissão para acessar esta página.",
          variant: "destructive",
        });
        navigate("/");
      } else {
        fetchAllData();
      }
    }
  }, [user, userRole, loading, navigate]);

  const fetchAllData = async () => {
    await Promise.all([
      fetchAppointments(),
      fetchBarbeiros(),
      fetchServicos(),
      fetchHorarios(),
    ]);
    setIsLoading(false);
  };

  // Agendamentos Functions
  const fetchAppointments = async () => {
    try {
      const { data, error } = await supabaseQuery
        .from("appointments")
        .select("*")
        .order("data", { ascending: true })
        .order("horario", { ascending: true });

      if (error) throw error;
      setAppointments(data || []);
      setFilteredAppointments(data || []);
    } catch (error: any) {
      toast({
        title: "Erro ao carregar agendamentos",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleStatusChange = async (appointmentId: string, newStatus: string) => {
    try {
      const { error } = await supabaseQuery
        .from("appointments")
        .update({ status: newStatus })
        .eq("id", appointmentId);

      if (error) throw error;

      toast({
        title: "Status atualizado",
        description: "O status do agendamento foi atualizado com sucesso.",
      });

      fetchAppointments();
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar status",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    let filtered = [...appointments];

    if (statusFilter !== "todos") {
      filtered = filtered.filter((apt) => apt.status === statusFilter);
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (dateFilter === "hoje") {
      filtered = filtered.filter((apt) => {
        const aptDate = parseLocalDate(apt.data);
        aptDate.setHours(0, 0, 0, 0);
        return aptDate.getTime() === today.getTime();
      });
    } else if (dateFilter === "proximos") {
      filtered = filtered.filter((apt) => {
        const aptDate = parseLocalDate(apt.data);
        aptDate.setHours(0, 0, 0, 0);
        return aptDate.getTime() >= today.getTime();
      });
    } else if (dateFilter === "passados") {
      filtered = filtered.filter((apt) => {
        const aptDate = parseLocalDate(apt.data);
        aptDate.setHours(0, 0, 0, 0);
        return aptDate.getTime() < today.getTime();
      });
    }

    setFilteredAppointments(filtered);
  }, [statusFilter, dateFilter, appointments]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return <Badge className="bg-yellow-500">Pendente</Badge>;
      case "cancelado":
        return <Badge variant="destructive">Cancelado</Badge>;
      case "concluido":
        return <Badge className="bg-blue-500">Concluído</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  // Barbeiros Functions
  const fetchBarbeiros = async () => {
    try {
      const { data, error } = await supabaseQuery
        .from("barbeiros")
        .select("*")
        .order("nome", { ascending: true });

      if (error) throw error;
      setBarbeiros(data || []);
    } catch (error: any) {
      toast({
        title: "Erro ao carregar barbeiros",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleBarbeiroSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingBarbeiro) {
        // Editing existing barbeiro - use edit schema (no password)
        const validated = barbeiroEditSchema.parse({
          nome: barbeiroForm.nome,
          nome_exibicao: barbeiroForm.nome_exibicao,
          email: barbeiroForm.email || undefined,
          telefone: barbeiroForm.telefone || undefined,
        });

        const { error } = await supabaseQuery
          .from("barbeiros")
          .update(validated)
          .eq("id", editingBarbeiro);

        if (error) throw error;

        toast({
          title: "Barbeiro atualizado",
          description: "As informações foram atualizadas com sucesso.",
        });
        
        setBarbeiroForm({ nome: "", nome_exibicao: "", telefone: "", email: "", senha: "" });
        setEditingBarbeiro(null);
        fetchBarbeiros();
      } else {
        // Creating new barbeiro - use full schema with password
        const validated = barbeiroSchema.parse(barbeiroForm);
        
        setIsCreatingBarbeiro(true);

        // Call edge function to create user account and barbeiro
        const { data: { session } } = await supabase.auth.getSession();
        
        const response = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/criar-barbeiro`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${session?.access_token}`,
            },
            body: JSON.stringify(validated),
          }
        );

        const result = await response.json();

        if (!response.ok) {
          throw new Error(result.error || "Erro ao criar barbeiro");
        }

        toast({
          title: "Barbeiro cadastrado com sucesso!",
          description: `Credenciais de acesso:\nEmail: ${validated.email}\nSenha: ${validated.senha}`,
        });
        
        setBarbeiroForm({ nome: "", nome_exibicao: "", telefone: "", email: "", senha: "" });
        fetchBarbeiros();
      }
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Erro de validação",
          description: error.errors[0].message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Erro ao salvar barbeiro",
          description: error.message,
          variant: "destructive",
        });
      }
    } finally {
      setIsCreatingBarbeiro(false);
    }
  };

  const handleEditBarbeiro = (barbeiro: Barbeiro) => {
    setEditingBarbeiro(barbeiro.id);
    setBarbeiroForm({
      nome: barbeiro.nome,
      nome_exibicao: barbeiro.nome_exibicao || "",
      telefone: barbeiro.telefone || "",
      email: barbeiro.email || "",
      senha: "",
    });
  };

  const handleCancelEditBarbeiro = () => {
    setEditingBarbeiro(null);
    setBarbeiroForm({ nome: "", nome_exibicao: "", telefone: "", email: "", senha: "" });
  };

  const handleDeleteBarbeiro = async () => {
    if (!deletingBarbeiroId) return;

    try {
      const { error } = await supabaseQuery
        .from("barbeiros")
        .delete()
        .eq("id", deletingBarbeiroId);

      if (error) throw error;

      toast({
        title: "Barbeiro removido",
        description: "O barbeiro foi removido com sucesso.",
      });

      fetchBarbeiros();
    } catch (error: any) {
      toast({
        title: "Erro ao remover barbeiro",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setDeletingBarbeiroId(null);
    }
  };

  const toggleBarbeiroAtivo = async (id: string, ativo: boolean) => {
    try {
      const { error } = await supabaseQuery
        .from("barbeiros")
        .update({ ativo: !ativo })
        .eq("id", id);

      if (error) throw error;

      toast({
        title: ativo ? "Barbeiro desativado" : "Barbeiro ativado",
        description: `O barbeiro foi ${ativo ? "desativado" : "ativado"} com sucesso.`,
      });

      fetchBarbeiros();
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar status",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Serviços Functions
  const fetchServicos = async () => {
    try {
      const { data, error } = await supabaseQuery
        .from("servicos")
        .select("*")
        .order("nome", { ascending: true });

      if (error) throw error;
      setServicos(data || []);
    } catch (error: any) {
      toast({
        title: "Erro ao carregar serviços",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleServicoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const validated = servicoSchema.parse({
        nome: servicoForm.nome,
        preco: parseFloat(servicoForm.preco),
        duracao_minutos: parseInt(servicoForm.duracao_minutos),
      });

      if (editingServico) {
        const { error } = await supabaseQuery
          .from("servicos")
          .update(validated)
          .eq("id", editingServico);

        if (error) throw error;

        toast({
          title: "Serviço atualizado",
          description: "As informações foram atualizadas com sucesso.",
        });
      } else {
        const { error } = await supabaseQuery
          .from("servicos")
          .insert([validated]);

        if (error) throw error;

        toast({
          title: "Serviço cadastrado",
          description: "O serviço foi adicionado com sucesso.",
        });
      }

      setServicoForm({ nome: "", preco: "", duracao_minutos: "" });
      setEditingServico(null);
      fetchServicos();
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Erro de validação",
          description: error.errors[0].message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Erro ao salvar serviço",
          description: error.message,
          variant: "destructive",
        });
      }
    }
  };

  const handleEditServico = (servico: Servico) => {
    setEditingServico(servico.id);
    setServicoForm({
      nome: servico.nome,
      preco: servico.preco.toString(),
      duracao_minutos: servico.duracao_minutos.toString(),
    });
  };

  const handleCancelEditServico = () => {
    setEditingServico(null);
    setServicoForm({ nome: "", preco: "", duracao_minutos: "" });
  };

  const handleDeleteServico = async () => {
    if (!deletingServicoId) return;

    try {
      const { error } = await supabaseQuery
        .from("servicos")
        .delete()
        .eq("id", deletingServicoId);

      if (error) throw error;

      toast({
        title: "Serviço removido",
        description: "O serviço foi removido com sucesso.",
      });

      fetchServicos();
    } catch (error: any) {
      toast({
        title: "Erro ao remover serviço",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setDeletingServicoId(null);
    }
  };

  const toggleServicoAtivo = async (id: string, ativo: boolean) => {
    try {
      const { error } = await supabaseQuery
        .from("servicos")
        .update({ ativo: !ativo })
        .eq("id", id);

      if (error) throw error;

      toast({
        title: ativo ? "Serviço desativado" : "Serviço ativado",
        description: `O serviço foi ${ativo ? "desativado" : "ativado"} com sucesso.`,
      });

      fetchServicos();
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar status",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  // Horários Functions
  const fetchHorarios = async () => {
    try {
      const { data, error } = await supabaseQuery
        .from("horarios_funcionamento")
        .select("*")
        .order("dia_semana", { ascending: true });

      if (error) throw error;
      setHorarios(data || []);
    } catch (error: any) {
      toast({
        title: "Erro ao carregar horários",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleHorarioSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const validated = horarioSchema.parse({
        dia_semana: parseInt(horarioForm.dia_semana),
        horario_inicio: horarioForm.horario_inicio,
        horario_fim: horarioForm.horario_fim,
      });

      if (editingHorario) {
        const { error } = await supabaseQuery
          .from("horarios_funcionamento")
          .update(validated)
          .eq("id", editingHorario);

        if (error) throw error;

        toast({
          title: "Horário atualizado",
          description: "As informações foram atualizadas com sucesso.",
        });
      } else {
        const { error } = await supabaseQuery
          .from("horarios_funcionamento")
          .insert([validated]);

        if (error) throw error;

        toast({
          title: "Horário cadastrado",
          description: "O horário foi adicionado com sucesso.",
        });
      }

      setHorarioForm({ dia_semana: "", horario_inicio: "", horario_fim: "" });
      setEditingHorario(null);
      fetchHorarios();
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Erro de validação",
          description: error.errors[0].message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Erro ao salvar horário",
          description: error.message,
          variant: "destructive",
        });
      }
    }
  };

  const handleEditHorario = (horario: HorarioFuncionamento) => {
    setEditingHorario(horario.id);
    setHorarioForm({
      dia_semana: horario.dia_semana.toString(),
      horario_inicio: horario.horario_inicio,
      horario_fim: horario.horario_fim,
    });
  };

  const handleCancelEditHorario = () => {
    setEditingHorario(null);
    setHorarioForm({ dia_semana: "", horario_inicio: "", horario_fim: "" });
  };

  const handleDeleteHorario = async () => {
    if (!deletingHorarioId) return;

    try {
      const { error } = await supabaseQuery
        .from("horarios_funcionamento")
        .delete()
        .eq("id", deletingHorarioId);

      if (error) throw error;

      toast({
        title: "Horário removido",
        description: "O horário foi removido com sucesso.",
      });

      fetchHorarios();
    } catch (error: any) {
      toast({
        title: "Erro ao remover horário",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setDeletingHorarioId(null);
    }
  };

  const toggleHorarioAtivo = async (id: string, ativo: boolean) => {
    try {
      const { error } = await supabaseQuery
        .from("horarios_funcionamento")
        .update({ ativo: !ativo })
        .eq("id", id);

      if (error) throw error;

      toast({
        title: ativo ? "Horário bloqueado" : "Horário liberado",
        description: `O horário foi ${ativo ? "bloqueado" : "liberado"} com sucesso.`,
      });

      fetchHorarios();
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar status",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const getDiaSemanaLabel = (dia: number) => {
    const dias = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
    return dias[dia];
  };

  // Bloqueios Functions
  const fetchBloqueios = async () => {
    try {
      const { data, error } = await supabaseQuery
        .from("horarios_bloqueados")
        .select("*")
        .order("data", { ascending: true });

      if (error) throw error;
      setBloqueios(data || []);
    } catch (error: any) {
      toast({
        title: "Erro ao carregar bloqueios",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleBloqueioSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (!bloqueioForm.data || !bloqueioForm.horario_inicio || !bloqueioForm.horario_fim) {
        throw new Error("Preencha todos os campos obrigatórios");
      }

      const payload = {
        data: bloqueioForm.data,
        horario_inicio: bloqueioForm.horario_inicio,
        horario_fim: bloqueioForm.horario_fim,
        motivo: bloqueioForm.motivo || null,
      };

      if (editingBloqueio) {
        const { error } = await supabaseQuery
          .from("horarios_bloqueados")
          .update(payload)
          .eq("id", editingBloqueio);

        if (error) throw error;

        toast({
          title: "Bloqueio atualizado",
          description: "O bloqueio foi atualizado com sucesso.",
        });
      } else {
        const { error } = await supabaseQuery
          .from("horarios_bloqueados")
          .insert([payload]);

        if (error) throw error;

        toast({
          title: "Horário bloqueado",
          description: "O horário foi bloqueado com sucesso.",
        });
      }

      setBloqueioForm({ data: "", horario_inicio: "", horario_fim: "", motivo: "" });
      setEditingBloqueio(null);
      fetchBloqueios();
    } catch (error: any) {
      toast({
        title: "Erro ao salvar bloqueio",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleEditBloqueio = (bloqueio: HorarioBloqueado) => {
    setEditingBloqueio(bloqueio.id);
    setBloqueioForm({
      data: bloqueio.data,
      horario_inicio: bloqueio.horario_inicio,
      horario_fim: bloqueio.horario_fim,
      motivo: bloqueio.motivo || "",
    });
  };

  const handleCancelEditBloqueio = () => {
    setEditingBloqueio(null);
    setBloqueioForm({ data: "", horario_inicio: "", horario_fim: "", motivo: "" });
  };

  const handleDeleteBloqueio = async () => {
    if (!deletingBloqueioId) return;

    try {
      const { error } = await supabaseQuery
        .from("horarios_bloqueados")
        .delete()
        .eq("id", deletingBloqueioId);

      if (error) throw error;

      toast({
        title: "Bloqueio removido",
        description: "O bloqueio foi removido com sucesso.",
      });

      fetchBloqueios();
    } catch (error: any) {
      toast({
        title: "Erro ao remover bloqueio",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setDeletingBloqueioId(null);
    }
  };

  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 pt-20 pb-12 px-4">
        <div className="container mx-auto max-w-4xl">
          {currentView === "menu" && (
            <>
              <div className="mb-6">
                <h1 className="text-3xl font-bold mb-2">Painel Admin</h1>
                <p className="text-muted-foreground">Gerencie sua barbearia</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Card 
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => setCurrentView("agendamentos")}
                >
                  <CardHeader>
                    <Calendar className="h-10 w-10 mb-2 text-primary" />
                    <CardTitle>Agendamentos</CardTitle>
                    <CardDescription>
                      Visualize e gerencie todos os agendamentos
                    </CardDescription>
                  </CardHeader>
                </Card>

                <Card 
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => setCurrentView("barbeiros")}
                >
                  <CardHeader>
                    <Users className="h-10 w-10 mb-2 text-primary" />
                    <CardTitle>Barbeiros</CardTitle>
                    <CardDescription>
                      Cadastre e gerencie barbeiros
                    </CardDescription>
                  </CardHeader>
                </Card>

                <Card 
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => setCurrentView("servicos")}
                >
                  <CardHeader>
                    <Scissors className="h-10 w-10 mb-2 text-primary" />
                    <CardTitle>Serviços</CardTitle>
                    <CardDescription>
                      Configure serviços e preços
                    </CardDescription>
                  </CardHeader>
                </Card>

                <Card 
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => setCurrentView("horarios")}
                >
                  <CardHeader>
                    <Clock className="h-10 w-10 mb-2 text-primary" />
                    <CardTitle>Horários</CardTitle>
                    <CardDescription>
                      Defina horários de funcionamento
                    </CardDescription>
                  </CardHeader>
                </Card>

                <Card 
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => setCurrentView("bloqueios")}
                >
                  <CardHeader>
                    <CalendarOff className="h-10 w-10 mb-2 text-primary" />
                    <CardTitle>Bloqueios</CardTitle>
                    <CardDescription>
                      Bloqueie dias ou horários específicos
                    </CardDescription>
                  </CardHeader>
                </Card>
              </div>
            </>
          )}

          {currentView === "agendamentos" && (
            <>
              <Button
                variant="ghost"
                onClick={() => setCurrentView("menu")}
                className="mb-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>

              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-4">Agendamentos</h2>
                
                <Card className="mb-4">
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium mb-2 block">Status</Label>
                        <Select value={statusFilter} onValueChange={setStatusFilter}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="todos">Todos</SelectItem>
                            <SelectItem value="pendente">Pendente</SelectItem>
                            <SelectItem value="concluido">Concluído</SelectItem>
                            <SelectItem value="cancelado">Cancelado</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-sm font-medium mb-2 block">Período</Label>
                        <Select value={dateFilter} onValueChange={setDateFilter}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="todos">Todos</SelectItem>
                            <SelectItem value="hoje">Hoje</SelectItem>
                            <SelectItem value="proximos">Próximos</SelectItem>
                            <SelectItem value="passados">Passados</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="space-y-3">
                  {filteredAppointments.length === 0 ? (
                    <Card>
                      <CardContent className="pt-6 text-center text-muted-foreground">
                        Nenhum agendamento encontrado.
                      </CardContent>
                    </Card>
                  ) : (
                    filteredAppointments.map((appointment) => (
                      <Card key={appointment.id}>
                        <CardContent className="pt-6">
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <User className="h-4 w-4 text-muted-foreground" />
                                <span className="font-medium">{appointment.cliente_nome}</span>
                              </div>
                              {getStatusBadge(appointment.status)}
                            </div>
                            
                            <div className="space-y-2 text-sm">
                              <div className="flex items-center gap-2 text-muted-foreground">
                                <Phone className="h-4 w-4" />
                                <span>{appointment.cliente_telefone}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Scissors className="h-4 w-4 text-muted-foreground" />
                                <span>{appointment.servico}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-muted-foreground" />
                                <span>{format(parseLocalDate(appointment.data), "dd/MM/yyyy", { locale: ptBR })}</span>
                                <Clock className="h-4 w-4 text-muted-foreground ml-2" />
                                <span>{appointment.horario}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <User className="h-4 w-4 text-muted-foreground" />
                                <span>Barbeiro: {appointment.barbeiro}</span>
                              </div>
                            </div>

                            {appointment.status === "pendente" && (
                              <div className="flex gap-2 pt-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleStatusChange(appointment.id, "concluido")}
                                  className="flex-1"
                                >
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Concluir
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleStatusChange(appointment.id, "cancelado")}
                                  className="flex-1"
                                >
                                  <XCircle className="h-4 w-4 mr-1" />
                                  Cancelar
                                </Button>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </div>
            </>
          )}

          {currentView === "barbeiros" && (
            <>
              <Button
                variant="ghost"
                onClick={() => setCurrentView("menu")}
                className="mb-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>

              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-4">Barbeiros</h2>
                
                <Card className="mb-4">
                  <CardHeader>
                    <CardTitle>
                      {editingBarbeiro ? "Editar Barbeiro" : "Novo Barbeiro"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleBarbeiroSubmit} className="space-y-4">
                      <div>
                        <Label htmlFor="nome">Nome Completo*</Label>
                        <Input
                          id="nome"
                          value={barbeiroForm.nome}
                          onChange={(e) =>
                            setBarbeiroForm({ ...barbeiroForm, nome: e.target.value })
                          }
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="nome_exibicao">Nome de Exibição*</Label>
                        <Input
                          id="nome_exibicao"
                          value={barbeiroForm.nome_exibicao}
                          onChange={(e) =>
                            setBarbeiroForm({ ...barbeiroForm, nome_exibicao: e.target.value })
                          }
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="telefone">Telefone{!editingBarbeiro && "*"}</Label>
                        <PhoneInput
                          id="telefone"
                          value={barbeiroForm.telefone}
                          onChange={(e) =>
                            setBarbeiroForm({ ...barbeiroForm, telefone: e.target.value })
                          }
                          placeholder="(00) 00000-0000"
                          required={!editingBarbeiro}
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email{!editingBarbeiro && "*"}</Label>
                        <EmailInput
                          id="email"
                          value={barbeiroForm.email}
                          onChange={(e) =>
                            setBarbeiroForm({ ...barbeiroForm, email: e.target.value })
                          }
                          required={!editingBarbeiro}
                        />
                      </div>
                      {!editingBarbeiro && (
                        <div>
                          <Label htmlFor="senha">Senha*</Label>
                          <Input
                            id="senha"
                            type="password"
                            value={barbeiroForm.senha}
                            onChange={(e) =>
                              setBarbeiroForm({ ...barbeiroForm, senha: e.target.value })
                            }
                            placeholder="Mínimo 6 caracteres"
                            required
                            minLength={6}
                          />
                        </div>
                      )}
                      <div className="flex gap-2">
                        <Button type="submit" className="flex-1" disabled={isCreatingBarbeiro}>
                          <Save className="h-4 w-4 mr-2" />
                          {isCreatingBarbeiro ? "Criando conta..." : editingBarbeiro ? "Atualizar" : "Cadastrar"}
                        </Button>
                        {editingBarbeiro && (
                          <Button
                            type="button"
                            variant="outline"
                            onClick={handleCancelEditBarbeiro}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </form>
                  </CardContent>
                </Card>

                <div className="space-y-3">
                  {barbeiros.map((barbeiro) => (
                    <Card key={barbeiro.id}>
                      <CardContent className="pt-6">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{barbeiro.nome_exibicao || barbeiro.nome}</span>
                            <Badge variant={barbeiro.ativo ? "default" : "secondary"}>
                              {barbeiro.ativo ? "Ativo" : "Inativo"}
                            </Badge>
                          </div>
                          {barbeiro.telefone && (
                            <p className="text-sm text-muted-foreground">{barbeiro.telefone}</p>
                          )}
                          {barbeiro.email && (
                            <p className="text-sm text-muted-foreground">{barbeiro.email}</p>
                          )}
                          <div className="flex gap-2 pt-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditBarbeiro(barbeiro)}
                              className="flex-1"
                            >
                              <Pencil className="h-4 w-4 mr-1" />
                              Editar
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => toggleBarbeiroAtivo(barbeiro.id, barbeiro.ativo)}
                              className="flex-1"
                            >
                              {barbeiro.ativo ? "Desativar" : "Ativar"}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setDeletingBarbeiroId(barbeiro.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </>
          )}

          {currentView === "servicos" && (
            <>
              <Button
                variant="ghost"
                onClick={() => setCurrentView("menu")}
                className="mb-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>

              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-4">Serviços</h2>
                
                <Card className="mb-4">
                  <CardHeader>
                    <CardTitle>
                      {editingServico ? "Editar Serviço" : "Novo Serviço"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleServicoSubmit} className="space-y-4">
                      <div>
                        <Label htmlFor="servico_nome">Nome do Serviço*</Label>
                        <Input
                          id="servico_nome"
                          value={servicoForm.nome}
                          onChange={(e) =>
                            setServicoForm({ ...servicoForm, nome: e.target.value })
                          }
                          required
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="preco">Preço (R$)*</Label>
                          <Input
                            id="preco"
                            type="number"
                            step="0.01"
                            value={servicoForm.preco}
                            onChange={(e) =>
                              setServicoForm({ ...servicoForm, preco: e.target.value })
                            }
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="duracao">Duração (min)*</Label>
                          <Input
                            id="duracao"
                            type="number"
                            value={servicoForm.duracao_minutos}
                            onChange={(e) =>
                              setServicoForm({ ...servicoForm, duracao_minutos: e.target.value })
                            }
                            required
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button type="submit" className="flex-1">
                          <Save className="h-4 w-4 mr-2" />
                          {editingServico ? "Atualizar" : "Cadastrar"}
                        </Button>
                        {editingServico && (
                          <Button
                            type="button"
                            variant="outline"
                            onClick={handleCancelEditServico}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </form>
                  </CardContent>
                </Card>

                <div className="space-y-3">
                  {servicos.map((servico) => (
                    <Card key={servico.id}>
                      <CardContent className="pt-6">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{servico.nome}</span>
                            <Badge variant={servico.ativo ? "default" : "secondary"}>
                              {servico.ativo ? "Ativo" : "Inativo"}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span>{formatCurrency(servico.preco)}</span>
                            <span>•</span>
                            <span>{servico.duracao_minutos} minutos</span>
                          </div>
                          <div className="flex gap-2 pt-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditServico(servico)}
                              className="flex-1"
                            >
                              <Pencil className="h-4 w-4 mr-1" />
                              Editar
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => toggleServicoAtivo(servico.id, servico.ativo)}
                              className="flex-1"
                            >
                              {servico.ativo ? "Desativar" : "Ativar"}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setDeletingServicoId(servico.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </>
          )}

          {currentView === "horarios" && (
            <>
              <Button
                variant="ghost"
                onClick={() => setCurrentView("menu")}
                className="mb-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>

              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-4">Horários de Funcionamento</h2>
                
                <Card className="mb-4">
                  <CardHeader>
                    <CardTitle>
                      {editingHorario ? "Editar Horário" : "Novo Horário"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleHorarioSubmit} className="space-y-4">
                      <div>
                        <Label htmlFor="dia_semana">Dia da Semana*</Label>
                        <Select
                          value={horarioForm.dia_semana}
                          onValueChange={(value) =>
                            setHorarioForm({ ...horarioForm, dia_semana: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o dia" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="0">Domingo</SelectItem>
                            <SelectItem value="1">Segunda-feira</SelectItem>
                            <SelectItem value="2">Terça-feira</SelectItem>
                            <SelectItem value="3">Quarta-feira</SelectItem>
                            <SelectItem value="4">Quinta-feira</SelectItem>
                            <SelectItem value="5">Sexta-feira</SelectItem>
                            <SelectItem value="6">Sábado</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="horario_inicio">Horário Início*</Label>
                          <Input
                            id="horario_inicio"
                            type="time"
                            value={horarioForm.horario_inicio}
                            onChange={(e) =>
                              setHorarioForm({ ...horarioForm, horario_inicio: e.target.value })
                            }
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="horario_fim">Horário Fim*</Label>
                          <Input
                            id="horario_fim"
                            type="time"
                            value={horarioForm.horario_fim}
                            onChange={(e) =>
                              setHorarioForm({ ...horarioForm, horario_fim: e.target.value })
                            }
                            required
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button type="submit" className="flex-1">
                          <Save className="h-4 w-4 mr-2" />
                          {editingHorario ? "Atualizar" : "Cadastrar"}
                        </Button>
                        {editingHorario && (
                          <Button
                            type="button"
                            variant="outline"
                            onClick={handleCancelEditHorario}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </form>
                  </CardContent>
                </Card>

                <div className="space-y-3">
                  {horarios.map((horario) => (
                    <Card key={horario.id}>
                      <CardContent className="pt-6">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{getDiaSemanaLabel(horario.dia_semana)}</span>
                            <Badge variant={horario.ativo ? "default" : "secondary"}>
                              {horario.ativo ? "Liberado" : "Bloqueado"}
                            </Badge>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {horario.horario_inicio} - {horario.horario_fim}
                          </div>
                          <div className="flex gap-2 pt-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditHorario(horario)}
                              className="flex-1"
                            >
                              <Pencil className="h-4 w-4 mr-1" />
                              Editar
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => toggleHorarioAtivo(horario.id, horario.ativo)}
                              className="flex-1"
                            >
                              {horario.ativo ? "Bloquear" : "Liberar"}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setDeletingHorarioId(horario.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </>
          )}

          {currentView === "bloqueios" && (
            <>
              <Button
                variant="ghost"
                onClick={() => setCurrentView("menu")}
                className="mb-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>

              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-4">Bloqueio de Horários</h2>
                <p className="text-muted-foreground mb-6">
                  Bloqueie dias inteiros ou períodos específicos para todos ou barbeiros específicos.
                </p>
                
                <HorariosBloqueados 
                  isAdmin={true} 
                  barbeiros={barbeiros.map(b => ({ 
                    id: b.id, 
                    nome: b.nome, 
                    nome_exibicao: b.nome_exibicao 
                  }))} 
                />
              </div>
            </>
          )}
        </div>
      </main>

      <Footer />

      <AlertDialog open={!!deletingBarbeiroId} onOpenChange={() => setDeletingBarbeiroId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este barbeiro? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteBarbeiro}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!deletingServicoId} onOpenChange={() => setDeletingServicoId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este serviço? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteServico}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!deletingHorarioId} onOpenChange={() => setDeletingHorarioId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este horário? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteHorario}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Admin;
