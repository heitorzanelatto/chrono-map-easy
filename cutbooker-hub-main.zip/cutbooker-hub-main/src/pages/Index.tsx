import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Star, Calendar, Award, Users, CalendarCheck, Heart, Clock } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useAuth } from "@/hooks/useAuth";
import heroImage from "@/assets/hero-barber.jpg";
import work1 from "@/assets/work-1.jpg";
import work2 from "@/assets/work-2.jpg";
import work3 from "@/assets/work-3.jpg";
import work4 from "@/assets/work-4.jpg";

const Index = () => {
  const { user, userRole } = useAuth();
  const isBarbeiro = userRole === 'barbeiro';
  const isProprietario = userRole === 'proprietario';
  const isClient = user && !isBarbeiro && !isProprietario;
  
  const testimonials = [
    {
      name: "Carlos Silva",
      text: "Melhor barbearia que já fui! Atendimento impecável e resultado perfeito.",
      rating: 5,
    },
    {
      name: "Pedro Santos",
      text: "Profissionalismo e qualidade em cada detalhe. Recomendo muito!",
      rating: 5,
    },
    {
      name: "Lucas Oliveira",
      text: "Ambiente top e serviço de primeira. Virei cliente fiel!",
      rating: 5,
    },
  ];

  const stats = [
    { icon: Users, value: "5000+", label: "Clientes Satisfeitos" },
    { icon: Award, value: "10+", label: "Anos de Experiência" },
    { icon: Calendar, value: "15000+", label: "Cortes Realizados" },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-foreground/90 via-foreground/70 to-foreground/50 backdrop-blur-sm" />
        </div>
        
        <div className="relative z-10 container mx-auto px-6 text-center">
          <h1 className="text-6xl md:text-8xl font-light mb-6 text-background tracking-tight">
            Estilo e <span className="font-medium text-accent">Elegância</span>
          </h1>
          <p className="text-xl md:text-2xl mb-12 text-background/90 max-w-2xl mx-auto font-light">
            Transforme seu visual com os melhores profissionais da cidade
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {isBarbeiro ? (
              <Link to="/barbeiro">
                <Button variant="accent" size="lg">
                  Meu Painel
                </Button>
              </Link>
            ) : (
              <>
                <Link to="/agendar">
                  <Button variant="accent" size="lg">
                    Agendar Horário
                  </Button>
                </Link>
                <Link to="/servicos">
                  <Button variant="ghost" size="lg" className="bg-background/10 hover:bg-background/20 text-foreground backdrop-blur-sm">
                    Ver Serviços
                  </Button>
                </Link>
                {isClient && (
                <Link to="/meus-agendamentos">
                  <Button variant="ghost" size="lg" className="bg-background/10 hover:bg-background/20 text-foreground backdrop-blur-sm">
                    <CalendarCheck className="mr-2 h-5 w-5" />
                    Meus Agendamentos
                  </Button>
                </Link>
                )}
              </>
            )}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <stat.icon className="h-10 w-10 mx-auto mb-6 text-accent" />
                <h3 className="text-5xl font-light mb-3 text-foreground">{stat.value}</h3>
                <p className="text-muted-foreground text-sm">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-32">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-light mb-6 text-foreground">
              Nossos <span className="font-medium text-accent">Trabalhos</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto font-light">
              Confira alguns dos nossos melhores cortes e transformações
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[work1, work2, work3, work4].map((image, index) => (
              <div
                key={index}
                className="group relative overflow-hidden rounded-3xl aspect-square cursor-pointer"
              >
                <img
                  src={image}
                  alt={`Trabalho ${index + 1}`}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-32 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-light mb-6 text-foreground">
              Sobre a <span className="font-medium text-accent">Elite Barber</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto font-light leading-relaxed">
              Desde 2013, dedicados à arte da barbearia clássica combinada com técnicas modernas. 
              Mais de 10 anos de excelência, profissionalismo e paixão em cada atendimento.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            <Card className="p-8 text-center border-0 bg-background/50 backdrop-blur-sm">
              <Award className="h-10 w-10 text-accent mx-auto mb-6" />
              <h3 className="text-lg font-medium mb-3 text-foreground">Excelência</h3>
              <p className="text-muted-foreground text-sm font-light leading-relaxed">Buscamos sempre a perfeição em cada atendimento</p>
            </Card>
            <Card className="p-8 text-center border-0 bg-background/50 backdrop-blur-sm">
              <Users className="h-10 w-10 text-accent mx-auto mb-6" />
              <h3 className="text-lg font-medium mb-3 text-foreground">Respeito</h3>
              <p className="text-muted-foreground text-sm font-light leading-relaxed">Valorizamos cada cliente e suas necessidades</p>
            </Card>
            <Card className="p-8 text-center border-0 bg-background/50 backdrop-blur-sm">
              <Clock className="h-10 w-10 text-accent mx-auto mb-6" />
              <h3 className="text-lg font-medium mb-3 text-foreground">Pontualidade</h3>
              <p className="text-muted-foreground text-sm font-light leading-relaxed">Seu tempo é precioso e respeitamos isso</p>
            </Card>
            <Card className="p-8 text-center border-0 bg-background/50 backdrop-blur-sm">
              <Heart className="h-10 w-10 text-accent mx-auto mb-6" />
              <h3 className="text-lg font-medium mb-3 text-foreground">Paixão</h3>
              <p className="text-muted-foreground text-sm font-light leading-relaxed">Amamos o que fazemos e isso faz toda diferença</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-32 bg-background">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-light mb-6 text-foreground">
              O Que Dizem Nossos <span className="font-medium text-accent">Clientes</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-8 border-0 bg-muted/30">
                <div className="flex gap-1 mb-6">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-6 font-light leading-relaxed">{testimonial.text}</p>
                <p className="font-medium text-foreground">{testimonial.name}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      {!isBarbeiro && (
        <section className="py-32 bg-accent text-accent-foreground">
          <div className="container mx-auto px-6 text-center">
            <h2 className="text-5xl md:text-6xl font-light mb-8">
              Pronto Para Transformar Seu Visual?
            </h2>
            <p className="text-xl mb-12 text-accent-foreground/90 max-w-2xl mx-auto font-light">
              Agende seu horário agora e experimente o melhor serviço de barbearia da região
            </p>
            <Link to="/agendar">
              <Button variant="default" size="lg" className="bg-background text-foreground hover:bg-background/90">
                Agendar Agora
              </Button>
            </Link>
          </div>
        </section>
      )}

      <Footer />
    </div>
  );
};

export default Index;
