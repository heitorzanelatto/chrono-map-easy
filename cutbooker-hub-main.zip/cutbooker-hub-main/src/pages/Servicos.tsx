import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Scissors, Sparkles, Wind, Crown } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const Servicos = () => {
  const services = [
    {
      icon: Scissors,
      title: "Corte Tradicional",
      description: "Corte clássico com tesoura e máquina, ajustado ao seu estilo",
      price: "R$ 50,00",
      duration: "30 min",
    },
    {
      icon: Crown,
      title: "Corte Premium",
      description: "Corte moderno com técnicas avançadas e finalização profissional",
      price: "R$ 70,00",
      duration: "45 min",
    },
    {
      icon: Wind,
      title: "Barba & Bigode",
      description: "Design e modelagem completa com navalha e produtos premium",
      price: "R$ 40,00",
      duration: "30 min",
    },
    {
      icon: Sparkles,
      title: "Combo Completo",
      description: "Corte + Barba + Sobrancelha com tratamento especial",
      price: "R$ 100,00",
      duration: "60 min",
    },
    {
      icon: Scissors,
      title: "Corte Infantil",
      description: "Corte especial para crianças até 12 anos",
      price: "R$ 35,00",
      duration: "25 min",
    },
    {
      icon: Crown,
      title: "Dia do Noivo",
      description: "Pacote completo para o dia especial: corte, barba e tratamentos",
      price: "R$ 200,00",
      duration: "90 min",
    },
  ];

  const additionalServices = [
    { name: "Sobrancelha", price: "R$ 20,00" },
    { name: "Platinado", price: "R$ 80,00" },
    { name: "Luzes", price: "R$ 100,00" },
    { name: "Relaxamento", price: "R$ 60,00" },
    { name: "Hidratação Capilar", price: "R$ 50,00" },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero Section */}
      <section className="pt-40 pb-24 bg-background">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-6xl md:text-7xl font-light mb-8 text-foreground">
            Nossos <span className="font-medium text-accent">Serviços</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-light">
            Oferecemos uma ampla gama de serviços premium para cuidar do seu estilo
          </p>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="p-8 border-0 bg-muted/30 hover:shadow-[var(--shadow-lg)] transition-all duration-300">
                <service.icon className="h-10 w-10 text-accent mb-6" />
                <h3 className="text-xl font-medium mb-4 text-foreground">{service.title}</h3>
                <p className="text-muted-foreground mb-6 font-light leading-relaxed">{service.description}</p>
                <div className="flex items-center justify-between pt-6 border-t border-border">
                  <div>
                    <p className="text-3xl font-light text-accent">{service.price}</p>
                    <p className="text-sm text-muted-foreground mt-1">{service.duration}</p>
                  </div>
                  <Link to="/agendar">
                    <Button variant="accent" size="sm">Agendar</Button>
                  </Link>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-24 bg-muted/20">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-light mb-6 text-foreground">
              Serviços <span className="font-medium text-accent">Adicionais</span>
            </h2>
            <p className="text-lg text-muted-foreground font-light">
              Complemente seu visual com nossos tratamentos extras
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 max-w-5xl mx-auto">
            {additionalServices.map((service, index) => (
              <Card key={index} className="p-6 text-center border-0 bg-background/50 hover:bg-background transition-colors">
                <h4 className="font-medium mb-3 text-foreground">{service.name}</h4>
                <p className="text-accent font-light text-lg">{service.price}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-accent text-accent-foreground">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-5xl font-light mb-8">Agende Seu Horário</h2>
          <p className="text-xl mb-12 text-accent-foreground/90 max-w-2xl mx-auto font-light">
            Escolha o serviço ideal para você e garanta seu horário
          </p>
          <Link to="/agendar">
            <Button variant="default" size="lg" className="bg-background text-foreground hover:bg-background/90">
              Agendar Agora
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Servicos;
