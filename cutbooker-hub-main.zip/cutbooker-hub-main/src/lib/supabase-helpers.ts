import { supabase } from "@/integrations/supabase/client";

// Helper para contornar problemas de tipos do Supabase
export const supabaseQuery = {
  from: (table: string) => (supabase.from as any)(table)
};
