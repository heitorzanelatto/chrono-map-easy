import { Link } from "react-router-dom";
import { Phone, Mail, MapPin, Instagram, Facebook, Clock } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-muted border-t border-border">
      <div className="container mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div>
            <h3 className="text-base font-semibold mb-4 text-foreground">Elite Barber</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Excelência em cuidados masculinos com mais de 10 anos de experiência.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-4 text-foreground">Links Rápidos</h4>
            <div className="space-y-3">
              <Link to="/" className="block text-sm text-muted-foreground hover:text-accent transition-colors">
                Início
              </Link>
              <Link to="/servicos" className="block text-sm text-muted-foreground hover:text-accent transition-colors">
                Serviços
              </Link>
              <Link to="/agendar" className="block text-sm text-muted-foreground hover:text-accent transition-colors">
                Agendar
              </Link>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-4 text-foreground">Horário</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="flex items-start gap-2">
                <Clock className="h-4 w-4 mt-0.5 text-accent shrink-0" />
                <div className="space-y-1">
                  <p>Seg - Sex: 9h às 20h</p>
                  <p>Sábado: 9h às 18h</p>
                  <p>Domingo: Fechado</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold mb-4 text-foreground">Contato</h4>
            <div className="space-y-3 text-sm text-muted-foreground">
              <a href="tel:+5511999999999" className="flex items-center gap-2 hover:text-accent transition-colors">
                <Phone className="h-4 w-4 text-accent" />
                (11) 99999-9999
              </a>
              <a href="mailto:contato@elitebarber.com" className="flex items-center gap-2 hover:text-accent transition-colors">
                <Mail className="h-4 w-4 text-accent" />
                contato@elitebarber.com
              </a>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 text-accent shrink-0" />
                <span>Av. Paulista, 1000<br/>São Paulo, SP</span>
              </div>
            </div>

            <div className="flex gap-4 mt-6">
              <a href="#" className="text-muted-foreground hover:text-accent transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-accent transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-12 pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Elite Barber. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
