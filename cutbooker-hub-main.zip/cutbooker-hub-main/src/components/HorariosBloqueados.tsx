import { useState, useEffect } from "react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Calendar as CalendarIcon, Clock, Plus, Pencil, X, Trash2, CalendarOff } from "lucide-react";
import { supabaseQuery } from "@/lib/supabase-helpers";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface HorarioBloqueado {
  id: string;
  data: string;
  horario_inicio: string;
  horario_fim: string;
  motivo: string | null;
  barbeiro_id: string | null;
}

interface Barbeiro {
  id: string;
  nome: string;
  nome_exibicao: string | null;
}

interface HorariosBloqueadosProps {
  barbeiroId?: string; // Se fornecido, mostra apenas bloqueios deste barbeiro
  barbeiros?: Barbeiro[]; // Lista de barbeiros (apenas para admin)
  isAdmin?: boolean; // Se true, permite selecionar barbeiro e ver todos
}

const HorariosBloqueados = ({ barbeiroId, barbeiros = [], isAdmin = false }: HorariosBloqueadosProps) => {
  const { toast } = useToast();
  const [bloqueios, setBloqueios] = useState<HorarioBloqueado[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingBloqueio, setEditingBloqueio] = useState<string | null>(null);
  const [deletingBloqueioId, setDeletingBloqueioId] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [isDiaInteiro, setIsDiaInteiro] = useState(false);
  const [bloqueioForm, setBloqueioForm] = useState({
    horario_inicio: "08:00",
    horario_fim: "18:00",
    motivo: "",
    barbeiro_id: barbeiroId || "",
  });

  const parseLocalDate = (dateString: string): Date => {
    const [year, month, day] = dateString.split('-').map(Number);
    return new Date(year, month - 1, day);
  };

  useEffect(() => {
    fetchBloqueios();
  }, [barbeiroId, isAdmin]);

  const fetchBloqueios = async () => {
    try {
      let query = supabaseQuery
        .from("horarios_bloqueados")
        .select("*")
        .order("data", { ascending: true });

      // Se não é admin, filtra apenas pelo barbeiro específico
      if (!isAdmin && barbeiroId) {
        query = query.eq("barbeiro_id", barbeiroId);
      }

      const { data, error } = await query;

      if (error) throw error;
      setBloqueios(data || []);
    } catch (error: any) {
      toast({
        title: "Erro ao carregar bloqueios",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedDate) {
      toast({
        title: "Data obrigatória",
        description: "Selecione uma data para o bloqueio.",
        variant: "destructive",
      });
      return;
    }

    try {
      const dataFormatted = format(selectedDate, "yyyy-MM-dd");
      
      const payload: any = {
        data: dataFormatted,
        horario_inicio: isDiaInteiro ? "00:00" : bloqueioForm.horario_inicio,
        horario_fim: isDiaInteiro ? "23:59" : bloqueioForm.horario_fim,
        motivo: bloqueioForm.motivo || null,
        barbeiro_id: bloqueioForm.barbeiro_id || null,
      };

      if (editingBloqueio) {
        const { error } = await supabaseQuery
          .from("horarios_bloqueados")
          .update(payload)
          .eq("id", editingBloqueio);

        if (error) throw error;

        toast({
          title: "Bloqueio atualizado",
          description: "O bloqueio foi atualizado com sucesso.",
        });
      } else {
        const { error } = await supabaseQuery
          .from("horarios_bloqueados")
          .insert([payload]);

        if (error) throw error;

        toast({
          title: "Horário bloqueado",
          description: "O horário foi bloqueado com sucesso.",
        });
      }

      resetForm();
      fetchBloqueios();
    } catch (error: any) {
      toast({
        title: "Erro ao salvar bloqueio",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleEdit = (bloqueio: HorarioBloqueado) => {
    setEditingBloqueio(bloqueio.id);
    setSelectedDate(parseLocalDate(bloqueio.data));
    const isFullDay = bloqueio.horario_inicio === "00:00:00" && bloqueio.horario_fim === "23:59:00";
    setIsDiaInteiro(isFullDay);
    setBloqueioForm({
      horario_inicio: bloqueio.horario_inicio.slice(0, 5),
      horario_fim: bloqueio.horario_fim.slice(0, 5),
      motivo: bloqueio.motivo || "",
      barbeiro_id: bloqueio.barbeiro_id || "",
    });
  };

  const resetForm = () => {
    setEditingBloqueio(null);
    setSelectedDate(undefined);
    setIsDiaInteiro(false);
    setBloqueioForm({
      horario_inicio: "08:00",
      horario_fim: "18:00",
      motivo: "",
      barbeiro_id: barbeiroId || "",
    });
  };

  const handleDelete = async () => {
    if (!deletingBloqueioId) return;

    try {
      const { error } = await supabaseQuery
        .from("horarios_bloqueados")
        .delete()
        .eq("id", deletingBloqueioId);

      if (error) throw error;

      toast({
        title: "Bloqueio removido",
        description: "O bloqueio foi removido com sucesso.",
      });

      fetchBloqueios();
    } catch (error: any) {
      toast({
        title: "Erro ao remover bloqueio",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setDeletingBloqueioId(null);
    }
  };

  const getBarbeiroNome = (barbeiroId: string | null) => {
    if (!barbeiroId) return "Todos";
    const barbeiro = barbeiros.find(b => b.id === barbeiroId);
    return barbeiro?.nome_exibicao || barbeiro?.nome || "Desconhecido";
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            {editingBloqueio ? "Editar Bloqueio" : "Bloquear Horário"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Seletor de barbeiro (apenas para admin) */}
            {isAdmin && barbeiros.length > 0 && (
              <div>
                <Label>Barbeiro</Label>
                <Select
                  value={bloqueioForm.barbeiro_id || "todos"}
                  onValueChange={(value) =>
                    setBloqueioForm({ ...bloqueioForm, barbeiro_id: value === "todos" ? "" : value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o barbeiro (ou todos)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os barbeiros</SelectItem>
                    {barbeiros.map((barbeiro) => (
                      <SelectItem key={barbeiro.id} value={barbeiro.id}>
                        {barbeiro.nome_exibicao || barbeiro.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Seletor de data */}
            <div>
              <Label>Data*</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !selectedDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? (
                      format(selectedDate, "dd/MM/yyyy", { locale: ptBR })
                    ) : (
                      "Selecione a data"
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Toggle dia inteiro */}
            <div className="flex items-center justify-between">
              <Label htmlFor="dia-inteiro">Bloquear dia inteiro</Label>
              <Switch
                id="dia-inteiro"
                checked={isDiaInteiro}
                onCheckedChange={setIsDiaInteiro}
              />
            </div>

            {/* Horários personalizados */}
            {!isDiaInteiro && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="horario_inicio">Início*</Label>
                  <Input
                    id="horario_inicio"
                    type="time"
                    value={bloqueioForm.horario_inicio}
                    onChange={(e) =>
                      setBloqueioForm({ ...bloqueioForm, horario_inicio: e.target.value })
                    }
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="horario_fim">Fim*</Label>
                  <Input
                    id="horario_fim"
                    type="time"
                    value={bloqueioForm.horario_fim}
                    onChange={(e) =>
                      setBloqueioForm({ ...bloqueioForm, horario_fim: e.target.value })
                    }
                    required
                  />
                </div>
              </div>
            )}

            {/* Motivo */}
            <div>
              <Label htmlFor="motivo">Motivo (opcional)</Label>
              <Input
                id="motivo"
                value={bloqueioForm.motivo}
                onChange={(e) =>
                  setBloqueioForm({ ...bloqueioForm, motivo: e.target.value })
                }
                placeholder="Ex: Folga, Consulta médica, etc."
              />
            </div>

            <div className="flex gap-2">
              <Button type="submit" className="flex-1">
                <Plus className="h-4 w-4 mr-2" />
                {editingBloqueio ? "Atualizar" : "Bloquear"}
              </Button>
              {editingBloqueio && (
                <Button type="button" variant="outline" onClick={resetForm}>
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Lista de bloqueios */}
      <Card>
        <CardHeader>
          <CardTitle>Bloqueios Cadastrados</CardTitle>
        </CardHeader>
        <CardContent>
          {bloqueios.length === 0 ? (
            <p className="text-center text-muted-foreground py-4">
              Nenhum bloqueio cadastrado.
            </p>
          ) : (
            <div className="space-y-3">
              {bloqueios.map((bloqueio) => {
                const isFullDay = 
                  bloqueio.horario_inicio === "00:00:00" && 
                  bloqueio.horario_fim === "23:59:00";
                
                return (
                  <div
                    key={bloqueio.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">
                          {format(parseLocalDate(bloqueio.data), "dd/MM/yyyy", { locale: ptBR })}
                        </span>
                        {isFullDay ? (
                          <Badge variant="destructive">Dia Inteiro</Badge>
                        ) : (
                          <Badge variant="secondary">
                            {bloqueio.horario_inicio.slice(0, 5)} - {bloqueio.horario_fim.slice(0, 5)}
                          </Badge>
                        )}
                      </div>
                      {isAdmin && (
                        <p className="text-sm text-muted-foreground">
                          Barbeiro: {getBarbeiroNome(bloqueio.barbeiro_id)}
                        </p>
                      )}
                      {bloqueio.motivo && (
                        <p className="text-sm text-muted-foreground">
                          {bloqueio.motivo}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleEdit(bloqueio)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setDeletingBloqueioId(bloqueio.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog de confirmação de exclusão */}
      <AlertDialog open={!!deletingBloqueioId} onOpenChange={() => setDeletingBloqueioId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remover Bloqueio</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja remover este bloqueio? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Remover</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default HorariosBloqueados;
