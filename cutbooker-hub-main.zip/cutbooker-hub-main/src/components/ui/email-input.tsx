import * as React from "react";
import { cn } from "@/lib/utils";

const EMAIL_DOMAINS = [
  "@gmail.com",
  "@outlook.com",
  "@hotmail.com",
  "@yahoo.com",
  "@icloud.com",
];

export interface EmailInputProps extends React.ComponentProps<"input"> {
  value?: string;
}

const EmailInput = React.forwardRef<HTMLInputElement, EmailInputProps>(
  ({ className, value, ...props }, ref) => {
    const [showSuggestions, setShowSuggestions] = React.useState(false);
    const [filteredDomains, setFilteredDomains] = React.useState<string[]>([]);

    React.useEffect(() => {
      if (value && !value.includes("@")) {
        setFilteredDomains(EMAIL_DOMAINS);
        setShowSuggestions(true);
      } else if (value && value.includes("@")) {
        const [, domain] = value.split("@");
        if (domain.length === 0) {
          setFilteredDomains(EMAIL_DOMAINS);
          setShowSuggestions(true);
        } else {
          setShowSuggestions(false);
        }
      } else {
        setShowSuggestions(false);
      }
    }, [value]);

    const handleSuggestionClick = (domain: string) => {
      const emailPart = value?.split("@")[0] || "";
      const newValue = emailPart + domain;
      
      if (props.onChange) {
        const syntheticEvent = {
          target: { value: newValue },
          currentTarget: { value: newValue },
        } as React.ChangeEvent<HTMLInputElement>;
        props.onChange(syntheticEvent);
      }
      setShowSuggestions(false);
    };

    return (
      <div className="relative w-full">
        <input
          type="email"
          className={cn(
            "flex h-11 w-full rounded-xl border border-input bg-background px-4 py-2.5 text-base transition-colors ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/20 focus-visible:ring-offset-0 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
            className,
          )}
          ref={ref}
          value={value}
          {...props}
        />
        {showSuggestions && filteredDomains.length > 0 && (
          <div className="absolute z-50 w-full mt-1 bg-background border border-border rounded-lg shadow-lg overflow-hidden">
            {filteredDomains.map((domain) => (
              <button
                key={domain}
                type="button"
                onClick={() => handleSuggestionClick(domain)}
                className="w-full px-4 py-2 text-left text-sm hover:bg-accent transition-colors"
              >
                {value?.split("@")[0]}{domain}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  },
);
EmailInput.displayName = "EmailInput";

export { EmailInput };
