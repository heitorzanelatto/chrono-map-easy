import * as React from "react";
import InputMask from "react-input-mask";
import { cn } from "@/lib/utils";

export interface PhoneInputProps extends Omit<React.ComponentProps<"input">, "onChange"> {
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const PhoneInput = React.forwardRef<HTMLInputElement, PhoneInputProps>(
  ({ className, ...props }, ref) => {
    return (
      <InputMask
        mask="(99) 99999-9999"
        {...props}
      >
        {(inputProps: any) => (
          <input
            {...inputProps}
            ref={ref}
            type="tel"
            className={cn(
              "flex h-11 w-full rounded-xl border border-input bg-background px-4 py-2.5 text-base transition-colors ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/20 focus-visible:ring-offset-0 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
              className,
            )}
          />
        )}
      </InputMask>
    );
  },
);
PhoneInput.displayName = "PhoneInput";

export { PhoneInput };
