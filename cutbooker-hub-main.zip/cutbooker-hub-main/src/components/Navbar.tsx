import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Scissors, User, LogOut, ChevronRight } from "lucide-react";
import { Button } from "./ui/button";
import { useAuth } from "@/hooks/useAuth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { user, userRole, signOut } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close menu on route change
  useEffect(() => {
    setIsOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) => location.pathname === path;

  const navLinks = [
    { path: "/", label: "Início" },
    { path: "/servicos", label: "Serviços" },
    ...(userRole === "proprietario" ? [{ path: "/admin", label: "Admin" }] : []),
    ...(userRole === "barbeiro" ? [{ path: "/barbeiro", label: "Meu Painel" }] : []),
  ];

  return (
    <>
      <nav
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
          scrolled
            ? "bg-background/80 backdrop-blur-2xl border-b border-border/50 shadow-sm"
            : "bg-background/60 backdrop-blur-xl"
        )}
      >
        <div className="container mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2.5 group">
              <div className="p-2 rounded-xl bg-accent/10 group-hover:bg-accent/20 transition-colors">
                <Scissors className="h-5 w-5 text-accent group-hover:rotate-45 transition-transform duration-300" />
              </div>
              <span className="text-lg font-semibold text-foreground tracking-tight hidden sm:block">
                Elite Barber
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={cn(
                    "px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200",
                    isActive(link.path)
                      ? "bg-accent/10 text-accent"
                      : "text-foreground/70 hover:text-foreground hover:bg-muted/50"
                  )}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center gap-3">
              <Link to="/agendar">
                <Button variant="accent" size="sm">
                  Agendar
                </Button>
              </Link>

              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="gap-2">
                      <div className="w-7 h-7 rounded-full bg-accent/10 flex items-center justify-center">
                        <User className="h-4 w-4 text-accent" />
                      </div>
                      <span className="hidden lg:inline">Conta</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel className="font-normal">
                      <p className="text-sm font-medium">
                        {userRole === "proprietario"
                          ? "Proprietário"
                          : userRole === "barbeiro"
                          ? "Barbeiro"
                          : "Cliente"}
                      </p>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    {userRole === "proprietario" && (
                      <DropdownMenuItem asChild>
                        <Link to="/admin" className="cursor-pointer">
                          Painel Admin
                        </Link>
                      </DropdownMenuItem>
                    )}
                    {userRole === "barbeiro" && (
                      <DropdownMenuItem asChild>
                        <Link to="/barbeiro" className="cursor-pointer">
                          Meu Painel
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem asChild>
                      <Link to="/perfil" className="cursor-pointer">
                        Meus Dados
                      </Link>
                    </DropdownMenuItem>
                    {userRole !== "barbeiro" && userRole !== "proprietario" && (
                      <DropdownMenuItem asChild>
                        <Link to="/meus-agendamentos" className="cursor-pointer">
                          Meus Agendamentos
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => signOut()} className="text-destructive">
                      <LogOut className="h-4 w-4 mr-2" />
                      Sair
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link to="/auth">
                  <Button variant="ghost" size="sm">
                    Entrar
                  </Button>
                </Link>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 -mr-2 rounded-xl hover:bg-muted/50 transition-colors touch-manipulation"
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle menu"
            >
              <div className="relative w-6 h-6">
                <span
                  className={cn(
                    "absolute left-0 w-6 h-0.5 bg-foreground transition-all duration-300",
                    isOpen ? "top-[11px] rotate-45" : "top-[5px]"
                  )}
                />
                <span
                  className={cn(
                    "absolute left-0 top-[11px] w-6 h-0.5 bg-foreground transition-all duration-300",
                    isOpen ? "opacity-0" : "opacity-100"
                  )}
                />
                <span
                  className={cn(
                    "absolute left-0 w-6 h-0.5 bg-foreground transition-all duration-300",
                    isOpen ? "top-[11px] -rotate-45" : "top-[17px]"
                  )}
                />
              </div>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div
        className={cn(
          "fixed inset-0 z-40 bg-background/80 backdrop-blur-xl md:hidden transition-all duration-300",
          isOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        )}
        onClick={() => setIsOpen(false)}
      />

      {/* Mobile Menu Panel */}
      <div
        className={cn(
          "fixed top-16 left-0 right-0 bottom-0 z-40 bg-background md:hidden",
          "transition-all duration-300 ease-out overflow-y-auto",
          isOpen ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4 pointer-events-none"
        )}
      >
        <div className="container mx-auto px-4 py-6 space-y-2">
          {/* Navigation Links */}
          {navLinks.map((link, index) => (
            <Link
              key={link.path}
              to={link.path}
              className={cn(
                "flex items-center justify-between p-4 rounded-2xl transition-all duration-200",
                "animate-fade-in",
                isActive(link.path)
                  ? "bg-accent/10 text-accent"
                  : "text-foreground hover:bg-muted/50"
              )}
              style={{ animationDelay: `${index * 50}ms` }}
              onClick={() => setIsOpen(false)}
            >
              <span className="text-base font-medium">{link.label}</span>
              <ChevronRight className="h-5 w-5 opacity-40" />
            </Link>
          ))}

          <div className="h-px bg-border/50 my-4" />

          {/* CTA Button */}
          <Link
            to="/agendar"
            onClick={() => setIsOpen(false)}
            className="block animate-fade-in"
            style={{ animationDelay: "150ms" }}
          >
            <Button variant="accent" className="w-full h-14 text-base font-semibold">
              Agendar Horário
            </Button>
          </Link>

          <div className="h-px bg-border/50 my-4" />

          {/* User Section */}
          {user ? (
            <div className="space-y-2 animate-fade-in" style={{ animationDelay: "200ms" }}>
              <div className="flex items-center gap-3 p-4 rounded-2xl bg-muted/30">
                <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
                  <User className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-sm font-medium">
                    {userRole === "proprietario"
                      ? "Proprietário"
                      : userRole === "barbeiro"
                      ? "Barbeiro"
                      : "Cliente"}
                  </p>
                  <p className="text-xs text-muted-foreground">Conectado</p>
                </div>
              </div>

              {userRole === "proprietario" && (
                <Link
                  to="/admin"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center justify-between p-4 rounded-2xl hover:bg-muted/50 transition-colors"
                >
                  <span className="font-medium">Painel Admin</span>
                  <ChevronRight className="h-5 w-5 opacity-40" />
                </Link>
              )}
              {userRole === "barbeiro" && (
                <Link
                  to="/barbeiro"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center justify-between p-4 rounded-2xl hover:bg-muted/50 transition-colors"
                >
                  <span className="font-medium">Meu Painel</span>
                  <ChevronRight className="h-5 w-5 opacity-40" />
                </Link>
              )}
              <Link
                to="/perfil"
                onClick={() => setIsOpen(false)}
                className="flex items-center justify-between p-4 rounded-2xl hover:bg-muted/50 transition-colors"
              >
                <span className="font-medium">Meus Dados</span>
                <ChevronRight className="h-5 w-5 opacity-40" />
              </Link>
              {userRole !== "barbeiro" && userRole !== "proprietario" && (
                <Link
                  to="/meus-agendamentos"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center justify-between p-4 rounded-2xl hover:bg-muted/50 transition-colors"
                >
                  <span className="font-medium">Meus Agendamentos</span>
                  <ChevronRight className="h-5 w-5 opacity-40" />
                </Link>
              )}

              <button
                onClick={() => {
                  signOut();
                  setIsOpen(false);
                }}
                className="flex items-center gap-3 w-full p-4 rounded-2xl text-destructive hover:bg-destructive/10 transition-colors"
              >
                <LogOut className="h-5 w-5" />
                <span className="font-medium">Sair</span>
              </button>
            </div>
          ) : (
            <Link
              to="/auth"
              onClick={() => setIsOpen(false)}
              className="block animate-fade-in"
              style={{ animationDelay: "200ms" }}
            >
              <Button variant="outline" className="w-full h-14 text-base font-medium">
                <User className="h-5 w-5 mr-2" />
                Entrar
              </Button>
            </Link>
          )}
        </div>
      </div>
    </>
  );
};

export default Navbar;
